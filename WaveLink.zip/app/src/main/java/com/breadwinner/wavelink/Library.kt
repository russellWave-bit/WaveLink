package com.breadwinner.wavelink

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** One thing on a shelf. kind is "file" or "app". */
data class LibFile(
    val name: String, val size: Long, val kind: String,
    val uri: Uri?, val path: String?, val pkg: String = "", val note: String = ""
) {
    val key: String get() = uri?.toString() ?: path ?: name
}

fun Item.key(): String = uri?.toString() ?: path ?: name

/** Files the person picked by hand (documents and so on). They stay on the Files shelf. */
val pickedFiles = mutableStateListOf<LibFile>()

fun toggleItem(f: LibFile) {
    val have = Hub.items.firstOrNull { it.key() == f.key }
    if (have != null) Hub.items.remove(have)
    else Hub.items.add(Item(Hub.nextId(), f.name, f.size, f.kind, f.uri, f.path))
}

fun mimeOfName(name: String): String {
    val ext = name.substringAfterLast('.', "").lowercase()
    return android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
}

fun mediaPerms(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33) arrayOf(
        Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO, Manifest.permission.READ_MEDIA_AUDIO
    ) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

fun mediaGranted(c: Context): Boolean =
    mediaPerms().any { ContextCompat.checkSelfPermission(c, it) == PackageManager.PERMISSION_GRANTED }

fun queryMedia(c: Context, base: Uri, limit: Int = 400): List<LibFile> {
    val out = ArrayList<LibFile>()
    val proj = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE)
    try {
        c.contentResolver.query(base, proj, null, null, MediaStore.MediaColumns.DATE_ADDED + " DESC")?.use { cur ->
            val ci = cur.getColumnIndexOrThrow(MediaStore.MediaColumns._ID)
            val ni = cur.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
            val si = cur.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
            while (cur.moveToNext() && out.size < limit) {
                val id = cur.getLong(ci)
                out.add(
                    LibFile(
                        cur.getString(ni) ?: "file", if (cur.isNull(si)) -1L else cur.getLong(si), "file",
                        ContentUris.withAppendedId(base, id), null
                    )
                )
            }
        }
    } catch (e: Exception) {
    }
    return out
}

fun queryApps(c: Context): List<LibFile> {
    val pm = c.packageManager
    return try {
        pm.getInstalledApplications(0)
            .filter {
                (it.flags and ApplicationInfo.FLAG_SYSTEM) == 0 ||
                    (it.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0
            }
            .map {
                LibFile(
                    it.loadLabel(pm).toString() + ".apk", File(it.sourceDir).length(), "app",
                    null, it.sourceDir, it.packageName,
                    if ((it.splitSourceDirs?.size ?: 0) > 0) "several files" else ""
                )
            }
            .sortedBy { it.name.lowercase() }
    } catch (e: Exception) {
        emptyList()
    }
}

fun fileFromUri(c: Context, u: Uri): LibFile {
    try {
        c.contentResolver.takePersistableUriPermission(u, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
    } catch (e: Exception) {
    }
    var name = "file"
    var size = -1L
    try {
        c.contentResolver.query(u, null, null, null, null)?.use { cur ->
            if (cur.moveToFirst()) {
                val ni = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = cur.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = cur.getString(ni) ?: "file"
                if (si >= 0 && !cur.isNull(si)) size = cur.getLong(si)
            }
        }
    } catch (e: Exception) {
    }
    return LibFile(name, size, "file", u, null)
}

private val thumbCache = android.util.LruCache<String, ImageBitmap>(200)

@Composable
fun Thumb(f: LibFile, glyph: String) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(thumbCache.get(f.key), f.key) {
        if (value == null) {
            value = withContext(Dispatchers.IO) {
                try {
                    val u = f.uri
                    val b: android.graphics.Bitmap? = if (f.kind == "app") {
                        ctx.packageManager.getApplicationIcon(f.pkg).toBitmap(128, 128)
                    } else if (u != null) {
                        ctx.contentResolver.loadThumbnail(u, android.util.Size(240, 240), null)
                    } else null
                    val ib = b?.asImageBitmap()
                    if (ib != null) thumbCache.put(f.key, ib)
                    ib
                } catch (e: Exception) {
                    null
                }
            }
        }
    }
    val b = bmp
    if (b != null) {
        Image(
            bitmap = b, contentDescription = null,
            contentScale = if (f.kind == "app") ContentScale.Fit else ContentScale.Crop,
            modifier = if (f.kind == "app") Modifier.fillMaxSize().padding(14.dp) else Modifier.fillMaxSize()
        )
    } else {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            T(glyph, if (glyph.length > 2) 17 else 26, Muted, FontWeight.Bold)
        }
    }
}

@Composable
fun Tile(f: LibFile, on: Boolean, glyph: String, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Column(Modifier.width(96.dp).clickable { onClick() }) {
        Box(
            Modifier.size(96.dp)
                .shadow(5.dp, shape, ambientColor = Color(0x331E2D50), spotColor = Color(0x331E2D50))
                .clip(shape)
                .background(Brush.verticalGradient(listOf(Color.White, Color(0xFFD9DFE9))))
        ) {
            Thumb(f, glyph)
            Box(
                Modifier.matchParentSize().border(
                    if (on) 3.dp else 1.dp, if (on) Acc else Color.White, shape
                )
            )
            if (on) {
                Box(
                    Modifier.align(Alignment.TopEnd).padding(6.dp).size(22.dp).clip(CircleShape).background(Acc),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(Modifier.size(12.dp)) {
                        val w = 2.2.dp.toPx()
                        drawLine(Color.White, Offset(size.width * 0.12f, size.height * 0.52f), Offset(size.width * 0.4f, size.height * 0.8f), w, StrokeCap.Round)
                        drawLine(Color.White, Offset(size.width * 0.4f, size.height * 0.8f), Offset(size.width * 0.9f, size.height * 0.2f), w, StrokeCap.Round)
                    }
                }
            }
        }
        T(f.name, 11, TextC, FontWeight.SemiBold, maxLines = 1, modifier = Modifier.padding(top = 5.dp))
        T(if (f.note.isNotEmpty()) f.note else fmtSize(f.size), 10, Muted, FontWeight.Medium, maxLines = 1)
    }
}

@Composable
fun Shelf(
    title: String, files: List<LibFile>, sel: Set<String>, glyph: (LibFile) -> String,
    lead: (@Composable () -> Unit)? = null
) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            T(title, 17, modifier = Modifier.weight(1f))
            T(files.size.toString(), 12, Muted, FontWeight.Medium)
            if (files.isNotEmpty()) {
                val all = files.all { it.key in sel }
                T(
                    if (all) "None" else "All", 13, Acc,
                    modifier = Modifier.clickable {
                        if (all) files.forEach { if (it.key in sel) toggleItem(it) }
                        else files.forEach { if (it.key !in sel) toggleItem(it) }
                    }.padding(start = 12.dp, top = 8.dp, bottom = 8.dp)
                )
            }
        }
        Spacer(Modifier.height(6.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (lead != null) item { lead() }
            items(files, key = { it.key }) { f ->
                Tile(f, f.key in sel, glyph(f)) { toggleItem(f) }
            }
        }
        // the ledge of the shelf
        Spacer(Modifier.height(8.dp))
        Box(
            Modifier.padding(horizontal = 10.dp).fillMaxWidth().height(3.dp).clip(RoundedCornerShape(2.dp))
                .background(Brush.horizontalGradient(listOf(Color(0x00FFFFFF), Color(0xCCFFFFFF), Color(0x00FFFFFF))))
        )
    }
}

private fun ext(name: String): String {
    val e = name.substringAfterLast('.', "")
    return if (e.isEmpty() || e.length > 4) "FILE" else e.uppercase()
}

@Composable
fun LibraryPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var ok by remember { mutableStateOf(mediaGranted(ctx)) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { ok = mediaGranted(ctx) }
    LaunchedEffect(Unit) { if (!ok) ask.launch(mediaPerms()) }

    val photos by produceState<List<LibFile>>(emptyList(), ok) {
        value = if (ok) withContext(Dispatchers.IO) { queryMedia(ctx, MediaStore.Images.Media.EXTERNAL_CONTENT_URI) } else emptyList()
    }
    val videos by produceState<List<LibFile>>(emptyList(), ok) {
        value = if (ok) withContext(Dispatchers.IO) { queryMedia(ctx, MediaStore.Video.Media.EXTERNAL_CONTENT_URI) } else emptyList()
    }
    val music by produceState<List<LibFile>>(emptyList(), ok) {
        value = if (ok) withContext(Dispatchers.IO) { queryMedia(ctx, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI) } else emptyList()
    }
    val apps by produceState<List<LibFile>>(emptyList()) {
        value = withContext(Dispatchers.IO) { queryApps(ctx) }
    }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        for (u in uris) {
            val f = fileFromUri(ctx, u)
            if (pickedFiles.none { it.key == f.key }) pickedFiles.add(f)
            if (Hub.items.none { it.key() == f.key }) toggleItem(f)
        }
    }

    val sel = Hub.items.map { it.key() }.toHashSet()
    val total = Hub.items.sumOf { if (it.size > 0) it.size else 0L }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        SubHeader("Library", onBack)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            if (!ok) {
                item {
                    Column(Modifier.padding(horizontal = 16.dp)) {
                        RCard(Modifier.fillMaxWidth()) {
                            T("Photos, videos and music", 15)
                            Spacer(Modifier.height(4.dp))
                            T("Allow access so your shelves can fill up. Nothing leaves the phone until you share.", 12, Muted, FontWeight.Medium)
                            Spacer(Modifier.height(10.dp))
                            Pill("Allow") { ask.launch(mediaPerms()) }
                        }
                    }
                }
            }
            if (photos.isNotEmpty()) item { Shelf("Photos", photos, sel, { "" }) }
            if (videos.isNotEmpty()) item { Shelf("Videos", videos, sel, { "VIDEO" }) }
            if (music.isNotEmpty()) item { Shelf("Music", music, sel, { "♪" }) }
            item {
                Shelf("Apps", apps, sel, { "APK" })
            }
            item {
                Shelf("Files", pickedFiles.toList(), sel, { ext(it.name) }, lead = {
                    Box(
                        Modifier.size(96.dp).clip(RoundedCornerShape(18.dp))
                            .background(Color(0xB3FFFFFF)).border(1.dp, Hair, RoundedCornerShape(18.dp))
                            .clickable { pick.launch(arrayOf("*/*")) },
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            T("+", 28, Acc, FontWeight.Bold)
                            T("Add files", 11, Muted)
                        }
                    }
                })
            }
            item { Spacer(Modifier.height(8.dp)) }
        }
        // what is chosen
        Row(
            Modifier.fillMaxWidth().background(Color(0xE6FFFFFF)).navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                T(if (Hub.items.isEmpty()) "Nothing chosen" else "${Hub.items.size} chosen", 15)
                T(if (Hub.items.isEmpty()) "Tap things to choose them" else fmtSize(total), 11, Muted, FontWeight.Medium)
            }
            if (Hub.items.isNotEmpty()) {
                Pill("Clear", false) { Hub.items.clear() }
                Spacer(Modifier.width(8.dp))
            }
            Pill("Done") { onBack() }
        }
    }
}
