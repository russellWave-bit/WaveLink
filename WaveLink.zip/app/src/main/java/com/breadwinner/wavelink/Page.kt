package com.breadwinner.wavelink

/** The page the PC sees in its browser. */
const val PAGE = """<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>WaveLink</title>
<style>
*{box-sizing:border-box}
body{margin:0;min-height:100vh;color:#1E232B;font-family:system-ui,Segoe UI,Roboto,sans-serif;background:radial-gradient(900px 500px at 10% 0,#fff,transparent 60%),radial-gradient(800px 500px at 100% 100%,#f6f8fc,transparent 60%),linear-gradient(#EEF1F6,#C9D0DB) fixed}
.wrap{max-width:760px;margin:0 auto;padding:20px 16px 60px}
h1{font-size:30px;margin:8px 0 2px;letter-spacing:-.5px}
.sub{color:#68727F;margin:0 0 22px}
.card{background:linear-gradient(rgba(255,255,255,.9),rgba(255,255,255,.65));border:1px solid #fff;border-radius:20px;padding:18px;margin-bottom:16px;box-shadow:0 8px 28px rgba(30,45,80,.14)}
h2{font-size:15px;margin:0 0 12px}
#drop{border-radius:16px;background:rgba(255,255,255,.6);border:1px dashed rgba(30,35,43,.25);padding:28px 16px;text-align:center;color:#68727F}
#drop.over{background:rgba(63,111,181,.14);color:#1E232B;border-color:#3F6FB5}
label.btn,a.btn{display:inline-block;background:linear-gradient(#fff,#d3d9e3 60%,#e6eaf0);color:#1E232B;border:1px solid #fff;font-weight:700;padding:9px 18px;border-radius:14px;text-decoration:none;cursor:pointer;font-size:14px;box-shadow:0 4px 12px rgba(30,45,80,.22)}
.row{display:flex;align-items:center;gap:12px;padding:10px 0;border-top:1px solid rgba(30,35,43,.1)}
.row:first-child{border-top:0}
.tag{font-size:11px;font-weight:700;background:rgba(63,111,181,.12);color:#3F6FB5;border-radius:8px;padding:3px 8px}
.name{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.meta{color:#68727F;font-size:12px;margin-top:2px}
.bar{height:6px;border-radius:6px;background:rgba(30,35,43,.12);margin-top:6px;overflow:hidden}
.bar i{display:block;height:100%;width:0;background:linear-gradient(90deg,#3F6FB5,#8fb0e6,#3F6FB5);background-size:200% 100%;animation:sh 1.2s linear infinite}
@keyframes sh{to{background-position:-200% 0}}
.empty{color:#68727F;font-size:14px}
</style></head><body><div class="wrap">
<h1>WaveLink</h1><p class="sub" id="sub">Connected to the phone</p>
<div class="card"><h2>Send to the phone</h2>
<div id="drop">Drop files here, or<br><br><label class="btn">Choose files<input id="pick" type="file" multiple hidden></label></div>
<div id="ups"></div></div>
<div class="card"><h2>On the phone</h2><div id="list"><div class="empty">Loading...</div></div></div>
<script>
var queue=[],busy=false,lastP=-1,lastT=0;
function ping(p,n,force){var t=Date.now();if(!force&&(p===lastP||t-lastT<250))return;lastP=p;lastT=t;fetch('/api/progress?p='+p+'&n='+encodeURIComponent(n),{cache:'no-store'}).catch(function(){})}
function fmt(b){if(b<0)return '?';if(b>=1e9)return (b/1e9).toFixed(2)+' GB';if(b>=1e6)return (b/1e6).toFixed(1)+' MB';if(b>=1e3)return Math.round(b/1e3)+' KB';return b+' B'}
function el(t,c,x){var e=document.createElement(t);if(c)e.className=c;if(x!==undefined)e.textContent=x;return e}
function load(){
 fetch('/api/items',{cache:'no-store'}).then(function(r){return r.json()}).then(function(d){
  document.getElementById('sub').textContent='Connected to the phone';
  var box=document.getElementById('list');box.innerHTML='';
  if(!d.items.length){box.appendChild(el('div','empty','Nothing shared yet. On the phone, open the Share tab and add files or apps.'));return}
  d.items.forEach(function(it){
   var r=el('div','row');
   r.appendChild(el('span','tag',it.kind==='app'?'APP':'FILE'));
   var w=el('div');w.style.flex='1';w.style.minWidth='0';
   w.appendChild(el('div','name',it.name));
   w.appendChild(el('div','meta',fmt(it.size)));
   r.appendChild(w);
   var a=el('a','btn','Download');a.href='/dl/'+it.id;a.setAttribute('download',it.name);
   r.appendChild(a);box.appendChild(r);
  });
 }).catch(function(){document.getElementById('sub').textContent='Lost connection to the phone...'});
}
function enqueue(files){for(var i=0;i<files.length;i++)queue.push(files[i]);next()}
function next(){
 if(busy||!queue.length)return;busy=true;
 var f=queue.shift();
 var row=el('div','row');var w=el('div');w.style.flex='1';w.style.minWidth='0';
 var m=el('div','meta','Sending... 0%');var b=el('div','bar');var i=el('i');
 b.appendChild(i);w.appendChild(el('div','name',f.name));w.appendChild(m);w.appendChild(b);row.appendChild(w);
 document.getElementById('ups').insertBefore(row,document.getElementById('ups').firstChild);
 lastP=-1;var x=new XMLHttpRequest();x.open('POST','/upload');
 x.upload.onprogress=function(e){if(e.lengthComputable){var p=Math.round(e.loaded/e.total*100);i.style.width=p+'%';m.textContent='Sending... '+p+'%';ping(p,f.name,false)}};
 x.onload=function(){i.style.width='100%';m.textContent=x.status===200?'Sent. Saved on the phone in Downloads/WaveLink':'Failed';busy=false;next()};
 x.onerror=function(){m.textContent='Failed. Check the connection.';busy=false;next()};
 var fd=new FormData();fd.append('file',f,f.name);x.send(fd);
}
var pick=document.getElementById('pick'),drop=document.getElementById('drop');
pick.onchange=function(){enqueue(pick.files);pick.value=''};
drop.ondragover=function(e){e.preventDefault();drop.className='over'};
drop.ondragleave=function(){drop.className=''};
drop.ondrop=function(e){e.preventDefault();drop.className='';enqueue(e.dataTransfer.files)};
load();setInterval(load,3000);
</script></div></body></html>"""
