package com.breadwinner.wavelink

import android.content.Context
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.net.Inet4Address
import java.net.NetworkInterface
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/** Something the phone is offering to the PC. kind is "file" or "app". */
data class Item(val id: Int, val name: String, val size: Long, val kind: String, val uri: Uri?, val path: String?)

/** Something the PC sent to the phone. */
data class Got(val name: String, val size: Long, val time: Long, val uri: Uri?)

/** A PC asking to link with this phone. */
class PairReq(val pcId: String, val name: String)

/** Shared state between the service, the link server and the screens. */
object Hub {
    /** Bytes this phone has received from the PC, ever. Used for the speed read-out. */
    val rxBytes = AtomicLong(0)
    /** The connection lane really in use: 0 = existing Wi-Fi / my hotspot, 1 = auto hotspot, 2 = USB cable. */
    var eff by mutableStateOf(0)
    var pairReq by mutableStateOf<PairReq?>(null)
    @Volatile var pairAnswer = 0
    @Volatile var autoTried = false

    var running by mutableStateOf(false)
    /** 0 = my hotspot / Wi-Fi, 1 = auto hotspot, 2 = USB cable, 3 = smart (default): use the network that is there, else make a hotspot */
    var mode by mutableStateOf(3)
    var ssid by mutableStateOf("")
    var pass by mutableStateOf("")
    var hotspotMsg by mutableStateOf("")
    var port by mutableStateOf(8080)
    var devices by mutableStateOf(0)
    // live transfer progress: "send" = phone to PC, "recv" = PC to phone
    var sendOn by mutableStateOf(false)
    var sendP by mutableStateOf(0f)
    var sendName by mutableStateOf("")
    var sendOk by mutableStateOf(false)
    var sendEndAt by mutableStateOf(0L)
    var recvOn by mutableStateOf(false)
    var recvP by mutableStateOf(0f)
    var recvName by mutableStateOf("")
    var recvOk by mutableStateOf(false)
    var recvEndAt by mutableStateOf(0L)
    @Volatile private var recvSeen = 0L
    @Volatile private var recvDoneName = ""
    private val sendActive = AtomicInteger(0)

    val items = mutableStateListOf<Item>()
    val received = mutableStateListOf<Got>()

    private val ids = AtomicInteger(1)
    private val seen = ConcurrentHashMap<String, Long>()

    fun nextId(): Int = ids.getAndIncrement()

    fun init(c: Context) {
        mode = c.getSharedPreferences("wl", Context.MODE_PRIVATE).getInt("mode", 3)
    }

    fun setMode(c: Context, m: Int) {
        mode = m
        c.getSharedPreferences("wl", Context.MODE_PRIVATE).edit().putInt("mode", m).apply()
    }

    fun touch(ip: String) {
        seen[ip] = System.currentTimeMillis()
        recount()
    }

    fun recount() {
        val now = System.currentTimeMillis()
        devices = seen.values.count { now - it < 15_000 }
        if (recvOn && now - recvSeen > 8_000) recvEnd(false)
    }

    fun sendStart(name: String) {
        sendActive.incrementAndGet()
        sendName = name
        sendP = 0f
        sendOn = true
    }

    fun sendUpdate(f: Float) {
        sendP = f.coerceIn(0f, 1f)
    }

    fun sendEnd(ok: Boolean) {
        if (sendActive.decrementAndGet() <= 0) {
            sendActive.set(0)
            sendOn = false
            sendOk = ok
            sendEndAt = System.currentTimeMillis()
        }
    }

    fun recvUpdate(name: String, f: Float) {
        if (!recvOn && name == recvDoneName && System.currentTimeMillis() - recvEndAt < 2_000) return
        if (!recvOn || recvName != name) {
            recvName = name
            recvOn = true
        }
        recvP = f.coerceIn(0f, 1f)
        recvSeen = System.currentTimeMillis()
    }

    fun recvEnd(ok: Boolean) {
        recvDoneName = recvName
        recvOn = false
        recvOk = ok
        recvEndAt = System.currentTimeMillis()
    }

    fun resetProgress() {
        sendActive.set(0)
        sendOn = false
        recvOn = false
        sendP = 0f
        recvP = 0f
    }

    fun clearSeen() {
        seen.clear()
        devices = 0
    }
}

fun fmtSize(b: Long): String {
    if (b < 0) return "?"
    val d = b.toDouble()
    return when {
        d >= 1e9 -> String.format(Locale.US, "%.2f GB", d / 1e9)
        d >= 1e6 -> String.format(Locale.US, "%.1f MB", d / 1e6)
        d >= 1e3 -> String.format(Locale.US, "%.0f KB", d / 1e3)
        else -> "$b B"
    }
}

/** Finds the phone's address on the hotspot, USB cable or Wi-Fi. Returns (address, interface name). */
fun findIp(mode: Int): Pair<String, String>? {
    val found = ArrayList<Pair<String, String>>()
    try {
        val all = NetworkInterface.getNetworkInterfaces() ?: return null
        for (ni in all) {
            if (!ni.isUp || ni.isLoopback) continue
            for (a in ni.inetAddresses) {
                if (a is Inet4Address && a.isSiteLocalAddress) {
                    val host = a.hostAddress ?: continue
                    found.add(host to ni.name)
                }
            }
        }
    } catch (e: Exception) {
        return null
    }
    fun rank(n: String): Int {
        val usb = n.startsWith("rndis") || n.startsWith("usb") || n.startsWith("eth")
        val hot = n.startsWith("ap") || n.startsWith("swlan")
        val wifi = n.startsWith("wlan")
        return if (mode == 2) {
            when { usb -> 0; hot -> 1; wifi -> 2; else -> 3 }
        } else {
            when { hot -> 0; wifi -> 1; usb -> 2; else -> 3 }
        }
    }
    return found.minByOrNull { rank(it.second) }
}


/** True when the phone already sits on a Wi-Fi, hotspot or USB network the PC could be on. Mobile data does not count. */
fun hasLan(): Boolean {
    try {
        val all = NetworkInterface.getNetworkInterfaces() ?: return false
        for (ni in all) {
            if (!ni.isUp || ni.isLoopback) continue
            val n = ni.name
            val lan = n.startsWith("wlan") || n.startsWith("ap") || n.startsWith("swlan") || n.startsWith("rndis") || n.startsWith("usb") || n.startsWith("eth")
            if (!lan) continue
            for (a in ni.inetAddresses) if (a is Inet4Address && a.isSiteLocalAddress) return true
        }
    } catch (e: Exception) {
    }
    return false
}
