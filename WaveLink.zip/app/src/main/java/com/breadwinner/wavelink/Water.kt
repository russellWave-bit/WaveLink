package com.breadwinner.wavelink

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.RowScope
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.random.Random

/** Seconds, ticking every frame. Read it only inside a draw block so just the drawing is redone. */
@Composable
fun frameTime(): State<Float> = produceState(0f) {
    while (true) androidx.compose.runtime.withFrameNanos { value = it / 1e9f }
}

/** A watery surface: a filled shape whose top edge is a sine wave. */
private fun wavePath(w: Float, h: Float, level: Float, amp: Float, k: Float, phase: Float): Path {
    val p = Path()
    val top = h * (1f - level)
    p.moveTo(0f, h)
    var x = 0f
    while (x <= w + 4f) {
        p.lineTo(x, top + sin(x / w * 2f * PI.toFloat() * k + phase) * amp)
        x += 4f
    }
    p.lineTo(w, h)
    p.close()
    return p
}

/**
 * The big round water button. The water rises with the state of the link and with the transfer.
 * Tap it to start or stop sharing.
 */
@Composable
fun WaterOrb(
    level: Float, title: String, sub: String, burst: Int, size: Dp = 230.dp,
    onClick: () -> Unit
) {
    val lv by animateFloatAsState(level, tween(900), label = "lv")
    val tS = frameTime()
    Box(Modifier.size(size + 60.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(size)) {
            val t = tS.value
            val w = this.size.width
            val circle = Path().apply { addOval(androidx.compose.ui.geometry.Rect(0f, 0f, w, w)) }
            drawCircle(Paper, w / 2f, Offset(w / 2f, w / 2f))
            clipPath(circle) {
                drawPath(wavePath(w, w, lv, 7.dp.toPx(), 1.3f, t * 1.7f), Aqua.copy(alpha = 0.55f))
                drawPath(wavePath(w, w, lv - 0.02f, 6.dp.toPx(), 1.8f, -t * 2.3f + 1.5f), AquaD.copy(alpha = 0.75f))
                // a few bubbles drifting up inside the water
                for (k in 0 until 5) {
                    val ph = (t * 0.18f + k * 0.21f) % 1f
                    val bx = w * (0.2f + 0.15f * k) + sin(t + k) * 6.dp.toPx()
                    val by = w - ph * w * lv
                    drawCircle(Color.White.copy(alpha = 0.45f * (1f - ph)), (3 + k % 3).dp.toPx(), Offset(bx, by))
                }
            }
            drawCircle(Ink, w / 2f - 2.dp.toPx(), Offset(w / 2f, w / 2f), style = Stroke(3.5.dp.toPx()))
        }
        Column(Modifier.size(size).clip(CircleShape).clickable { onClick() }, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            T(title, 26, Ink, FontWeight.ExtraBold)
            T(sub, 12, Ink.copy(alpha = 0.75f), FontWeight.SemiBold)
        }
        SplashLayer(burst, Modifier.size(size + 60.dp), 0.5f, 0.42f, 1f)
    }
}

/**
 * The water splash: a crown of water tongues and a spray of falling drops.
 * Drawn again natively from the Sakuga recipe: seven tongues rising and falling, seven drops thrown out and pulled down.
 */
@Composable
fun SplashLayer(trigger: Int, modifier: Modifier, ox: Float, oy: Float, scale: Float) {
    val a = remember { Animatable(2f) }
    var seed = 0
    LaunchedEffect(trigger) {
        if (trigger > 0) {
            a.snapTo(0f)
            a.animateTo(1.4f, tween(1400, easing = LinearEasing))
        }
    }
    seed = trigger
    Canvas(modifier) {
        val t = a.value
        if (t < 1.4f) drawSplash(t, seed, size.width * ox, size.height * oy, density * scale)
    }
}

fun DrawScope.drawSplash(t: Float, seed: Int, ox: Float, oy: Float, u: Float) {
    // tongues: seven, each rising and falling over 0.7 s with its own lean and a small delay
    for (k in 0 until 7) {
        val r = Random(seed * 131 + k * 17 + 3)
        val lean = (k - 3) * 0.24f + (r.nextFloat() - 0.5f) * 0.3f
        val stagger = r.nextFloat() * 0.14f
        val l = (t - stagger) / 0.7f
        if (l <= 0f || l >= 1f) continue
        val big = 1f - abs(k - 3) * 0.13f
        val h = sin(l * PI.toFloat()) * (46f + r.nextFloat() * 26f) * big * u
        val wd = (12f - l * 4f) * u
        val bx = ox + (k - 3) * 9f * u
        val tx = bx + sin(lean) * h
        val ty = oy - cos(lean) * h
        val p = Path()
        p.moveTo(bx - wd / 2f, oy)
        p.quadraticBezierTo(bx - wd / 2f + (tx - bx) * 0.3f, oy - h * 0.55f, tx, ty)
        p.quadraticBezierTo(bx + wd / 2f + (tx - bx) * 0.3f, oy - h * 0.55f, bx + wd / 2f, oy)
        p.close()
        drawPath(p, Aqua)
        drawPath(p, Ink, style = Stroke(1.5f * u))
        drawCircle(Color.White, 2.2f * u, Offset(tx, ty))
    }
    // drops: seven, thrown out and pulled down
    for (k in 0 until 7) {
        val r = Random(seed * 977 + k * 29 + 11)
        val ang = (-PI / 2).toFloat() + (r.nextFloat() - 0.5f) * 2.2f
        val sp = (90f + r.nextFloat() * 90f) * u
        val rad = (2f + r.nextFloat() * 2f) * u
        if (t >= 1f) continue
        val shrink = if (t > 0.6f) 1f - (t - 0.6f) / 0.4f else 1f
        val x = ox + cos(ang) * sp * t
        val y = oy + sin(ang) * sp * t + 330f * u * t * t * 0.5f * 2f
        drawCircle(Aqua, rad * shrink, Offset(x, y))
        drawCircle(Ink, rad * shrink, Offset(x, y), style = Stroke(1.1f * u))
        drawCircle(Color.White, rad * shrink * 0.35f, Offset(x - rad * 0.3f, y - rad * 0.3f))
    }
}

/**
 * The one overall bar. Water pours along it, a crest rides the leading edge, drops fly off backwards,
 * a dashed ground line runs underneath with bubbles that lift as the water passes, and at 100 % it splashes.
 */
@Composable
fun WaterBar(frac: Float, mbs: Float, eta: Int, finished: Boolean, burst: Int, idleText: String = "Nothing moving yet") {
    val p by animateFloatAsState(frac.coerceIn(0f, 1f), tween(380), label = "wp")
    val tS = frameTime()
    val active = frac > 0f || finished
    Column(Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().height(110.dp)) {
            Canvas(Modifier.fillMaxWidth().height(110.dp)) {
                val t = tS.value
                val w = size.width
                val bh = 46.dp.toPx()
                val by = 24.dp.toPx()
                val bw = 3.5.dp.toPx()
                val rr = 16.dp.toPx()
                val ex = bw + (w - bw * 2) * p
                val inner = Path().apply {
                    addRoundRect(androidx.compose.ui.geometry.RoundRect(bw, by + bw, w - bw, by + bh - bw, CornerRadius(rr - bw)))
                }
                // track
                drawRoundRect(Color.White, Offset(0f, by), Size(w, bh), CornerRadius(rr))
                clipPath(inner) {
                    if (p > 0.002f) {
                        val fill = Path()
                        fill.moveTo(0f, by)
                        var y = 0f
                        while (y <= bh) {
                            fill.lineTo(ex + sin(y * 0.3f - t * 6f) * 3.5.dp.toPx(), by + y)
                            y += 3f
                        }
                        fill.lineTo(0f, by + bh)
                        fill.close()
                        drawPath(fill, Brush.horizontalGradient(listOf(Aqua, Deep), 0f, w))
                        clipPath(fill) {
                            for (k in 0..1) {
                                val line = Path()
                                var x = 0f
                                val yy = by + bh * (0.38f + 0.26f * k)
                                line.moveTo(0f, yy)
                                while (x <= w) {
                                    line.lineTo(x, yy + sin(x * 0.045f + t * (2.2f + k) + k * 2f) * 4.dp.toPx())
                                    x += 6f
                                }
                                drawPath(line, Color.White.copy(alpha = 0.4f), style = Stroke(2.dp.toPx(), cap = StrokeCap.Round))
                            }
                            for (k in 0..1) {
                                val sx = ((t * 70.dp.toPx() + k * w * 0.5f) % (ex + 90.dp.toPx())) - 40.dp.toPx()
                                val sk = Path()
                                sk.moveTo(sx, by)
                                sk.lineTo(sx + 16.dp.toPx(), by)
                                sk.lineTo(sx + 4.dp.toPx(), by + bh)
                                sk.lineTo(sx - 12.dp.toPx(), by + bh)
                                sk.close()
                                drawPath(sk, Color.White.copy(alpha = 0.22f))
                            }
                        }
                    }
                }
                // the crest riding the leading edge
                if (p > 0.01f && p < 0.999f) {
                    for (k in 0..4) {
                        val cy = by + bh * (k + 0.5f) / 5f
                        val h = (0.45f + sqrt(p) * 0.9f) * 15.dp.toPx() * (0.6f + 0.4f * sin(t * 5f + k * 1.7f))
                        val tp = Path()
                        tp.moveTo(ex - 2.dp.toPx(), cy - 5.dp.toPx())
                        tp.quadraticBezierTo(ex + h * 0.5f, cy - 5.dp.toPx(), ex + h, cy - h * 0.15f)
                        tp.quadraticBezierTo(ex + h * 0.45f, cy + 5.dp.toPx(), ex - 2.dp.toPx(), cy + 5.dp.toPx())
                        tp.close()
                        drawPath(tp, Aqua)
                        drawPath(tp, Ink, style = Stroke(1.5.dp.toPx()))
                        drawCircle(Color.White, 2.dp.toPx(), Offset(ex + h * 0.88f, cy - h * 0.12f))
                    }
                    // drops shed backwards and falling
                    val rate = (0.5f + (mbs / 12f).coerceIn(0f, 2f))
                    for (k in 0 until 8) {
                        val ph = (t * rate + k / 8f) % 1f
                        val r = Random(k * 7 + 1)
                        val s = ph * 0.8f
                        val x = ex - (30f + r.nextFloat() * 60f).dp.toPx() * s
                        val y = by + bh * (0.15f + r.nextFloat() * 0.7f) - (50f + r.nextFloat() * 70f).dp.toPx() * s + 620.dp.toPx() * s * s * 0.5f
                        val a = 1f - ph
                        if (y < by + bh + 18.dp.toPx()) {
                            drawCircle(Aqua.copy(alpha = a), 3.dp.toPx(), Offset(x, y))
                            drawCircle(Ink.copy(alpha = a * 0.8f), 3.dp.toPx(), Offset(x, y), style = Stroke(1.dp.toPx()))
                        }
                    }
                }
                drawRoundRect(Ink, Offset(bw / 2, by + bw / 2), Size(w - bw, bh - bw), CornerRadius(rr), style = Stroke(bw))

                // the ground: a dashed wavy line under the bar
                val gy = by + bh + 20.dp.toPx()
                val gp = Path()
                var gx = 0f
                gp.moveTo(0f, gy)
                while (gx <= w) {
                    gp.lineTo(gx, gy + sin(gx * 0.05f - t * 2f) * 2.dp.toPx())
                    gx += 6f
                }
                drawPath(
                    gp, Ink.copy(alpha = 0.55f),
                    style = Stroke(2.dp.toPx(), cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10.dp.toPx(), 7.dp.toPx()), -t * 30.dp.toPx()))
                )
                // bubbles that lift as the water passes
                for (k in 0 until 6) {
                    val bx = w * (k + 0.5f) / 6f
                    val near = abs(ex - bx)
                    val lift = if (active && near < 34.dp.toPx()) 9.dp.toPx() * (1f - near / 34.dp.toPx()) else 0f
                    val cy = gy - 8.dp.toPx() - lift
                    drawCircle(Color.White.copy(alpha = 0.85f), 5.dp.toPx(), Offset(bx, cy))
                    drawCircle(Ink.copy(alpha = 0.7f), 5.dp.toPx(), Offset(bx, cy), style = Stroke(1.5.dp.toPx()))
                }
                // done: a check badge
                if (finished && p > 0.99f) {
                    val c = Offset(w - 22.dp.toPx(), by + bh / 2)
                    drawCircle(Teal, 15.dp.toPx(), c)
                    drawCircle(Ink, 15.dp.toPx(), c, style = Stroke(2.dp.toPx()))
                    val ck = Path()
                    ck.moveTo(c.x - 6.dp.toPx(), c.y)
                    ck.lineTo(c.x - 1.5.dp.toPx(), c.y + 5.dp.toPx())
                    ck.lineTo(c.x + 7.dp.toPx(), c.y - 5.dp.toPx())
                    drawPath(ck, Color.White, style = Stroke(3.dp.toPx(), cap = StrokeCap.Round))
                }
            }
            SplashLayer(burst, Modifier.fillMaxWidth().height(110.dp), 0.92f, 0.5f, 0.9f)
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            // a leaning box with the percent
            Box(Modifier.padding(end = 6.dp, bottom = 4.dp)) {
                Box(
                    Modifier.offset(3.dp, 3.dp).graphicsLayer { rotationZ = -3f }
                        .background(Aqua, RoundedCornerShape(8.dp)).padding(horizontal = 14.dp, vertical = 6.dp)
                ) { androidx.compose.material3.Text("100%", color = Aqua, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, fontStyle = FontStyle.Italic) }
                Box(
                    Modifier.graphicsLayer { rotationZ = -3f }
                        .background(Color.White, RoundedCornerShape(8.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    androidx.compose.material3.Text(
                        (p * 100).toInt().toString() + "%", color = Ink, fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold, fontStyle = FontStyle.Italic
                    )
                }
            }
            Column(Modifier.weight(1f)) {
                T(
                    when {
                        finished -> "ザバーン!  All done"
                        active -> "ザザザ…  " + String.format(java.util.Locale.US, "%.1f MB/s", mbs)
                        else -> idleText
                    }, 13, if (finished) Teal else Ink, FontWeight.Bold, maxLines = 1
                )
                if (active && !finished) T(fmtEta(eta), 12, Mute, FontWeight.Medium)
            }
        }
    }
}
