package com.breadwinner.wavelink

import android.Manifest
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.common.HybridBinarizer
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** The app's own QR scanner. It uses the phone camera directly, nothing from Google. */
@Composable
fun ScanDialog(onResult: (String) -> Unit, onClose: () -> Unit) {
    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        QrScanner(onResult, onClose)
    }
}

@Composable
fun QrScanner(onResult: (String) -> Unit, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) {
        if (!granted) ask.launch(Manifest.permission.CAMERA)
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        if (granted) {
            ScanPreview(onResult)
            Canvas(Modifier.size(250.dp).align(Alignment.Center)) {
                drawRoundRect(
                    Color.White, Offset.Zero, Size(size.width, size.height),
                    CornerRadius(28.dp.toPx()), style = Stroke(3.dp.toPx())
                )
            }
            Text(
                "Point at the QR code", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.Center).padding(top = 300.dp)
            )
        } else {
            Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Allow the camera to scan the code", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(12.dp))
                Box(
                    Modifier.clip(RoundedCornerShape(16.dp)).background(Color.White)
                        .clickable { ask.launch(Manifest.permission.CAMERA) }.padding(horizontal = 20.dp, vertical = 11.dp)
                ) { Text("Allow", color = Color.Black, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
            }
        }
        Box(
            Modifier.align(Alignment.TopStart).statusBarsPadding().padding(16.dp)
                .clip(RoundedCornerShape(16.dp)).background(Color(0x55FFFFFF))
                .border(1.dp, Color(0x88FFFFFF), RoundedCornerShape(16.dp))
                .clickable { onClose() }.padding(horizontal = 18.dp, vertical = 10.dp)
        ) { Text("Close", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
private fun ScanPreview(onResult: (String) -> Unit) {
    val owner = LocalLifecycleOwner.current
    val done = remember { AtomicBoolean(false) }
    val exec = remember { Executors.newSingleThreadExecutor() }
    DisposableEffect(Unit) {
        onDispose { exec.shutdown() }
    }
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            val pv = PreviewView(c)
            pv.scaleType = PreviewView.ScaleType.FILL_CENTER
            val fut = ProcessCameraProvider.getInstance(c)
            fut.addListener({
                try {
                    val prov = fut.get()
                    val prev = Preview.Builder().build()
                    prev.setSurfaceProvider(pv.surfaceProvider)
                    val ana = ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .build()
                    val hints = HashMap<DecodeHintType, Any>()
                    hints[DecodeHintType.POSSIBLE_FORMATS] = listOf(BarcodeFormat.QR_CODE)
                    hints[DecodeHintType.TRY_HARDER] = true
                    val reader = MultiFormatReader()
                    reader.setHints(hints)
                    ana.setAnalyzer(exec) { img -> scanFrame(img, reader, done, onResult) }
                    prov.unbindAll()
                    prov.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, prev, ana)
                } catch (e: Exception) {
                }
            }, ContextCompat.getMainExecutor(c))
            pv
        }
    )
}

private fun scanFrame(img: ImageProxy, reader: MultiFormatReader, done: AtomicBoolean, cb: (String) -> Unit) {
    try {
        if (done.get()) return
        val plane = img.planes[0]
        val buf = plane.buffer
        val data = ByteArray(buf.remaining())
        buf.get(data)
        val src = PlanarYUVLuminanceSource(data, plane.rowStride, img.height, 0, 0, img.width, img.height, false)
        val res = reader.decodeWithState(BinaryBitmap(HybridBinarizer(src)))
        val text = res.text
        if (text != null && done.compareAndSet(false, true)) {
            Handler(Looper.getMainLooper()).post { cb(text) }
        }
    } catch (e: Exception) {
    } finally {
        reader.reset()
        img.close()
    }
}
