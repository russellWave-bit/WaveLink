package com.breadwinner.wavelink

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import org.json.JSONObject
import java.io.FileOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.security.SecureRandom
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/** Which PCs this phone trusts. A PC asks once, you tap Allow, and it is remembered. */
object Trust {
    private fun sp(c: Context) = c.getSharedPreferences("wl", Context.MODE_PRIVATE)

    fun phoneId(c: Context): String {
        var id = sp(c).getString("pid", null)
        if (id == null) {
            id = UUID.randomUUID().toString().take(8)
            sp(c).edit().putString("pid", id).apply()
        }
        return id
    }

    private fun map(c: Context): JSONObject = try { JSONObject(sp(c).getString("trust", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    /** A token for the phone-to-phone QR code. Made fresh each time the fast link starts. */
    @Volatile var p2pToken: String = ""

    fun newP2p() { p2pToken = newToken() }

    /** A PC whose QR code this phone just scanned. It may link without a tap on Allow, for a few minutes. */
    @Volatile private var expectId = ""
    @Volatile private var expectAt = 0L

    fun expect(pcId: String) {
        expectId = pcId
        expectAt = System.currentTimeMillis()
    }

    fun valid(c: Context, token: String?): Boolean {
        if (token.isNullOrEmpty()) return false
        if (token == p2pToken) return true
        val o = map(c)
        val it = o.keys()
        while (it.hasNext()) if (o.optString(it.next()) == token) return true
        return false
    }

    fun count(c: Context): Int = map(c).length()

    fun forgetAll(c: Context) { sp(c).edit().putString("trust", "{}").apply() }

    private fun add(c: Context, pcId: String, token: String) {
        val o = map(c)
        o.put(pcId, token)
        sp(c).edit().putString("trust", o.toString()).apply()
    }

    private fun newToken(): String {
        val chars = "abcdefghijkmnpqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val r = SecureRandom()
        val sb = StringBuilder()
        for (i in 0 until 28) sb.append(chars[r.nextInt(chars.length)])
        return sb.toString()
    }

    /** Called on a server thread. Waits up to a minute for the person to tap Allow. Returns a token, or null. */
    fun requestPair(c: Context, pcId: String, pcName: String): String? {
        if (expectId.isNotEmpty() && pcId == expectId && System.currentTimeMillis() - expectAt < 10 * 60_000) {
            expectId = ""
            val t = newToken()
            add(c, pcId, t)
            return t
        }
        synchronized(Hub) {
            if (Hub.pairReq != null) return null
            Hub.pairAnswer = 0
            Hub.pairReq = PairReq(pcId, pcName)
        }
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("pair", "Connection requests", NotificationManager.IMPORTANCE_HIGH))
            val open = PendingIntent.getActivity(c, 7, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            nm.notify(
                7,
                android.app.Notification.Builder(c, "pair").setSmallIcon(R.drawable.ic_stat)
                    .setContentTitle("$pcName wants to connect").setContentText("Open WaveLink and tap Allow")
                    .setContentIntent(open).setAutoCancel(true).build()
            )
        } catch (e: Exception) {
        }
        val end = System.currentTimeMillis() + 60_000
        while (System.currentTimeMillis() < end && Hub.pairAnswer == 0) Thread.sleep(150)
        val ok = Hub.pairAnswer == 1
        Hub.pairReq = null
        try { c.getSystemService(NotificationManager::class.java).cancel(7) } catch (e: Exception) { }
        if (!ok) return null
        val t = newToken()
        add(c, pcId, t)
        return t
    }
}

/** Sending side: counts the pieces the PC is pulling so the phone can show one smooth progress. */
object Tx {
    private val active = AtomicInteger(0)
    private val total = AtomicLong(0)
    private val sent = AtomicLong(0)

    fun begin(name: String, len: Long) {
        if (active.getAndIncrement() == 0) {
            total.set(0)
            sent.set(0)
            Hub.sendStart(name)
        }
        total.addAndGet(len)
        Flow.begin(name, true, len)
    }

    fun add(n: Long) {
        val s = sent.addAndGet(n)
        P2p.sent.addAndGet(n)
        Flow.bytes(n)
        Hub.sendUpdate(s.toFloat() / maxOf(1L, total.get()))
    }

    fun end(name: String, ok: Boolean) {
        Flow.end(name, true, ok)
        if (active.decrementAndGet() <= 0) {
            active.set(0)
            Hub.sendEnd(ok)
        }
    }
}

class RxSess(val name: String, val size: Long, val uri: Uri, val pfd: ParcelFileDescriptor) {
    val out = FileOutputStream(pfd.fileDescriptor)
    val ch = out.channel
    val got = AtomicLong(0)
    /** Bytes of pieces that arrived whole. Each piece counts once, even if the PC had to resend it. */
    val committed = AtomicLong(0)
    val pieces = ConcurrentHashMap<Long, Long>()
    @Volatile var last = System.currentTimeMillis()
}

/** Receiving side: files from the PC arrive in pieces, several at once, written straight into Downloads/WaveLink. */
object Rx {
    private val map = ConcurrentHashMap<String, RxSess>()
    private val total = AtomicLong(0)
    private val done = AtomicLong(0)
    @Volatile private var lastUi = 0L

    private fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    fun safeName(raw: String?): String {
        val n = (raw ?: "file").substringAfterLast('/').substringAfterLast('\\').trim()
        return if (n.isEmpty()) "file" else n
    }

    @Synchronized
    fun open(ctx: Context, sid: String, name: String, size: Long): RxSess {
        map[sid]?.let { return it }
        sweep(ctx)
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mimeOf(name))
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/WaveLink")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw IOException("Could not create the file")
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "rw") ?: throw IOException("Could not open the file")
        val s = RxSess(name, size, uri, pfd)
        map[sid] = s
        total.addAndGet(size)
        Flow.begin(name, false, size)
        Hub.recvUpdate(name, 0f)
        return s
    }

    /** Pieces that stopped arriving are cleaned up so no half files pile up. */
    private fun sweep(ctx: Context) {
        val now = System.currentTimeMillis()
        for ((k, s) in map.entries.toList()) {
            if (now - s.last > 120_000) {
                map.remove(k)
                total.addAndGet(-s.size)
                done.addAndGet(-s.got.get())
                Flow.end(s.name, false, false)
                try { s.ch.close(); s.pfd.close() } catch (e: Exception) { }
                try { ctx.contentResolver.delete(s.uri, null, null) } catch (e: Exception) { }
            }
        }
        if (map.isEmpty()) { total.set(0); done.set(0) }
    }

    fun add(s: RxSess, n: Long) {
        s.got.addAndGet(n)
        s.last = System.currentTimeMillis()
        done.addAndGet(n)
        Flow.bytes(n)
        Hub.rxBytes.addAndGet(n)
        val t = s.last
        if (t - lastUi > 100) {
            lastUi = t
            Hub.recvUpdate(s.name, done.get().toFloat() / maxOf(1L, total.get()))
        }
    }

    private val finished = ConcurrentHashMap<String, Long>()

    /** A piece we already finished (the PC resent it because it missed our answer). */
    fun isDone(sid: String): Boolean = finished.containsKey(sid)

    fun commit(s: RxSess, off: Long, len: Long) {
        if (s.pieces.putIfAbsent(off, len) == null) s.committed.addAndGet(len)
    }

    /** True when the file is complete and has been put in place. */
    fun maybeFinish(ctx: Context, sid: String, s: RxSess): Boolean {
        if (s.committed.get() < s.size) return false
        finished[sid] = System.currentTimeMillis()
        if (finished.size > 200) finished.clear()
        if (map.remove(sid) == null) return true
        try { s.ch.close(); s.pfd.close() } catch (e: Exception) { }
        val v = ContentValues()
        v.put(MediaStore.MediaColumns.IS_PENDING, 0)
        try { ctx.contentResolver.update(s.uri, v, null, null) } catch (e: Exception) { }
        Hub.received.add(0, Got(s.name, s.size, System.currentTimeMillis(), s.uri))
        Flow.end(s.name, false, true)
        if (map.isEmpty()) {
            total.set(0)
            done.set(0)
            Hub.recvEnd(true)
        }
        return true
    }

    fun write(s: RxSess, buf: ByteArray, n: Int, pos: Long) {
        val bb = ByteBuffer.wrap(buf, 0, n)
        var p = pos
        while (bb.hasRemaining()) p += s.ch.write(bb, p)
    }
}
