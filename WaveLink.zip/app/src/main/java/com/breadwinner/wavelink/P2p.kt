package com.breadwinner.wavelink

import android.content.ContentValues
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.Uri
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URLEncoder
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.nio.channels.ServerSocketChannel
import java.nio.channels.SocketChannel
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.coroutines.resume

/**
 * Phone to phone.
 *
 * Why it is fast: the two phones talk straight to each other over Wi-Fi (a private 5 GHz link made by the
 * sender), with no router and no internet. Bluetooth only manages about 2 Mbps in real life, so it is not
 * used for the files. A QR code carries the link name, password and address, so there is nothing to type.
 * The sender hands files to the network with sendfile (no copying through the app), and the receiver pulls
 * big files in four pieces at once and several files at the same time.
 */
object P2p {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    // sender
    var on by mutableStateOf(false)
    var qr by mutableStateOf("")
    var msg by mutableStateOf("")
    val sent = AtomicLong(0)

    // receiver
    var rxActive by mutableStateOf(false)
    var rxMsg by mutableStateOf("")
    var rxDone by mutableStateOf(0)
    var rxFiles by mutableStateOf(0)
    var rxFailed by mutableStateOf(0)
    var rxTotal by mutableStateOf(0L)
    val rxBytes = AtomicLong(0)
    private val doneA = AtomicInteger(0)
    private val failA = AtomicInteger(0)
    @Volatile var cb: ConnectivityManager.NetworkCallback? = null

    fun makeQr(ssid: String, pass: String, host: String, fast: Int): String =
        "wavelink://join?s=" + enc(ssid) + "&p=" + enc(pass) + "&h=" + host + "&f=" + fast

    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    fun resetSender() {
        on = false
        qr = ""
        msg = ""
        sent.set(0)
    }

    fun resetReceiver() {
        rxDone = 0
        rxFiles = 0
        rxFailed = 0
        rxTotal = 0L
        rxBytes.set(0)
        doneA.set(0)
        failA.set(0)
    }

    fun fileDone() { rxDone = doneA.incrementAndGet() }
    fun fileFailed() { rxFailed = failA.incrementAndGet() }
}

class Join(val ssid: String, val pass: String, val host: String, val fast: Int)

class Remote(val id: Int, val name: String, val size: Long, val kind: String)

fun parseJoin(text: String): Join? {
    return try {
        val u = Uri.parse(text.trim())
        if (u.scheme != "wavelink") return null
        val h = u.getQueryParameter("h") ?: return null
        Join(
            u.getQueryParameter("s") ?: "", u.getQueryParameter("p") ?: "", h,
            (u.getQueryParameter("f") ?: "8180").toInt()
        )
    } catch (e: Exception) {
        null
    }
}

/** Reads the header of a tiny HTTP message, up to the blank line. */
fun readHead(ins: InputStream): String? {
    val sb = StringBuilder()
    while (sb.length < 8192) {
        val b = ins.read()
        if (b < 0) return null
        sb.append(b.toChar())
        val n = sb.length
        if (n >= 4 && sb[n - 1] == '\n' && sb[n - 2] == '\r' && sb[n - 3] == '\n' && sb[n - 4] == '\r') return sb.toString()
    }
    return null
}

// ───────────────────────── SENDER: the fast server ─────────────────────────

/** Serves the chosen items to the other phone: GET /items and GET /f/<id> with Range. Zero-copy sendfile. */
class FastServer(private val ctx: Context) {
    private var ss: ServerSocketChannel? = null
    private val pool = Executors.newCachedThreadPool()
    @Volatile private var alive = false
    var port = 0

    fun start(): Boolean {
        for (p in 8180..8199) {
            try {
                val s = ServerSocketChannel.open()
                s.socket().reuseAddress = true
                s.socket().bind(InetSocketAddress(p))
                ss = s
                port = p
                alive = true
                break
            } catch (e: Exception) {
            }
        }
        val server = ss ?: return false
        pool.execute {
            while (alive) {
                try {
                    val c = server.accept()
                    pool.execute { serveOne(c) }
                } catch (e: Exception) {
                    if (!alive) break
                }
            }
        }
        return true
    }

    fun stop() {
        alive = false
        try { ss?.close() } catch (e: Exception) { }
        pool.shutdownNow()
    }

    private fun serveOne(ch: SocketChannel) {
        var started = false
        var ok = false
        var pfd: ParcelFileDescriptor? = null
        var fis: FileInputStream? = null
        try {
            val sock = ch.socket()
            sock.tcpNoDelay = true
            sock.sendBufferSize = 1 shl 20
            sock.soTimeout = 20000
            val head = readHead(sock.getInputStream()) ?: return
            val line = head.substringBefore("\r\n")
            val path = line.split(" ").getOrNull(1) ?: return
            val out = sock.getOutputStream()

            if (path == "/items") {
                val arr = JSONArray()
                for (f in Hub.items.toList()) {
                    arr.put(JSONObject().put("id", f.id).put("name", f.name).put("size", f.size).put("kind", f.kind))
                }
                val body = JSONObject().put("items", arr).toString().toByteArray()
                out.write(
                    ("HTTP/1.1 200 OK\r\nContent-Type: application/json\r\nContent-Length: " + body.size +
                        "\r\nConnection: close\r\n\r\n").toByteArray()
                )
                out.write(body)
                out.flush()
                return
            }

            val id = path.removePrefix("/f/").toIntOrNull()
            val item = Hub.items.toList().firstOrNull { it.id == id }
            if (id == null || item == null) {
                out.write("HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray())
                return
            }
            val p = item.path
            val u = item.uri
            val stream: FileInputStream = if (p != null) {
                FileInputStream(p)
            } else if (u != null) {
                val d = ctx.contentResolver.openFileDescriptor(u, "r") ?: return
                pfd = d
                FileInputStream(d.fileDescriptor)
            } else return
            fis = stream
            val fc = stream.channel
            var total = fc.size()
            if (total <= 0L) total = item.size
            if (total <= 0L) return

            var start = 0L
            var end = total - 1
            var ranged = false
            val m = Regex("(?i)range:\\s*bytes=(\\d+)-(\\d*)").find(head)
            if (m != null) {
                ranged = true
                start = m.groupValues[1].toLong()
                val e = m.groupValues[2]
                if (e.isNotEmpty()) end = minOf(end, e.toLong())
            }
            if (start > end) return
            val len = end - start + 1
            val h = if (ranged) {
                "HTTP/1.1 206 Partial Content\r\nContent-Range: bytes $start-$end/$total\r\n"
            } else "HTTP/1.1 200 OK\r\n"
            out.write((h + "Accept-Ranges: bytes\r\nContent-Length: $len\r\nConnection: close\r\n\r\n").toByteArray())
            out.flush()

            Hub.sendStart(item.name)
            started = true
            var pos = start
            val endExcl = end + 1
            var zero = 0
            while (pos < endExcl) {
                val n = fc.transferTo(pos, minOf(endExcl - pos, 4L shl 20), ch)
                if (n <= 0L) {
                    zero++
                    if (zero > 40) break
                    Thread.sleep(5)
                    continue
                }
                zero = 0
                pos += n
                P2p.sent.addAndGet(n)
            }
            ok = pos >= endExcl
        } catch (e: Exception) {
        } finally {
            if (started) Hub.sendEnd(ok)
            try { fis?.close() } catch (e: Exception) { }
            try { pfd?.close() } catch (e: Exception) { }
            try { ch.close() } catch (e: Exception) { }
        }
    }
}

// ───────────────────────── RECEIVER ─────────────────────────

private fun reach(host: String, port: Int, ms: Int, net: Network?): Boolean {
    val s = Socket()
    return try {
        net?.bindSocket(s)
        s.connect(InetSocketAddress(host, port), ms)
        true
    } catch (e: Exception) {
        false
    } finally {
        try { s.close() } catch (e: Exception) { }
    }
}

private suspend fun joinWifi(ctx: Context, j: Join): Network? = suspendCancellableCoroutine { cont ->
    val cm = ctx.getSystemService(ConnectivityManager::class.java)
    val spec = WifiNetworkSpecifier.Builder().setSsid(j.ssid).setWpa2Passphrase(j.pass).build()
    val req = NetworkRequest.Builder()
        .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
        .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        .setNetworkSpecifier(spec)
        .build()
    val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            if (cont.isActive) cont.resume(network)
        }

        override fun onUnavailable() {
            if (cont.isActive) cont.resume(null)
        }
    }
    P2p.cb = callback
    try {
        cm.requestNetwork(req, callback, 40000)
    } catch (e: Exception) {
        if (cont.isActive) cont.resume(null)
    }
    cont.invokeOnCancellation {
        try { cm.unregisterNetworkCallback(callback) } catch (e: Exception) { }
    }
}

private fun fetchItems(j: Join, net: Network?): List<Remote> {
    val s = Socket()
    try {
        net?.bindSocket(s)
        s.connect(InetSocketAddress(j.host, j.fast), 6000)
        s.soTimeout = 10000
        s.getOutputStream().write("GET /items HTTP/1.1\r\nHost: x\r\nConnection: close\r\n\r\n".toByteArray())
        val ins = s.getInputStream()
        readHead(ins) ?: throw IOException("no answer")
        val txt = String(ins.readBytes())
        val arr = JSONObject(txt).getJSONArray("items")
        val out = ArrayList<Remote>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.add(Remote(o.getInt("id"), o.getString("name"), o.optLong("size", -1L), o.optString("kind", "file")))
        }
        return out
    } finally {
        try { s.close() } catch (e: Exception) { }
    }
}

/** Pulls one byte range (or the whole file when to < 0) and writes it into the file at the right place. */
private fun pull(j: Join, net: Network?, r: Remote, fc: FileChannel, from: Long, to: Long) {
    val s = Socket()
    try {
        s.receiveBufferSize = 1 shl 20
        s.tcpNoDelay = true
        net?.bindSocket(s)
        s.connect(InetSocketAddress(j.host, j.fast), 8000)
        s.soTimeout = 20000
        val range = if (to >= 0) "Range: bytes=$from-$to\r\n" else ""
        s.getOutputStream().write(
            ("GET /f/" + r.id + " HTTP/1.1\r\nHost: x\r\n" + range + "Connection: close\r\n\r\n").toByteArray()
        )
        val ins = s.getInputStream()
        val head = readHead(ins) ?: throw IOException("no answer")
        val code = head.substringBefore("\r\n").split(" ").getOrNull(1)
        if (code != "200" && code != "206") throw IOException("refused")
        val buf = ByteArray(512 * 1024)
        var pos = from
        while (true) {
            val n = ins.read(buf)
            if (n < 0) break
            val bb = ByteBuffer.wrap(buf, 0, n)
            var p = pos
            while (bb.hasRemaining()) p += fc.write(bb, p)
            pos += n
            P2p.rxBytes.addAndGet(n.toLong())
        }
        if (to >= 0 && pos <= to) throw IOException("cut short")
        if (to < 0 && r.size > 0 && pos < r.size) throw IOException("cut short")
    } finally {
        try { s.close() } catch (e: Exception) { }
    }
}

private suspend fun downloadOne(ctx: Context, j: Join, net: Network?, r: Remote): Uri = withContext(Dispatchers.IO) {
    val resolver = ctx.contentResolver
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, r.name)
        put(MediaStore.MediaColumns.MIME_TYPE, mimeOfName(r.name))
        put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/WaveLink")
        put(MediaStore.MediaColumns.IS_PENDING, 1)
    }
    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw IOException("Could not create the file")
    var ok = false
    try {
        val pfd = resolver.openFileDescriptor(uri, "rw") ?: throw IOException("Could not open the file")
        pfd.use {
            val fc = FileOutputStream(it.fileDescriptor).channel
            val parts = if (r.size >= 32L * 1024 * 1024) 4 else 1
            if (parts > 1) {
                val per = (r.size + parts - 1) / parts
                coroutineScope {
                    (0 until parts).map { i ->
                        async {
                            val a = i * per
                            val b = minOf(r.size - 1, a + per - 1)
                            if (a <= b) pull(j, net, r, fc, a, b)
                        }
                    }.awaitAll()
                }
            } else {
                pull(j, net, r, fc, 0L, -1L)
            }
        }
        ok = true
    } finally {
        if (ok) {
            val v = ContentValues()
            v.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, v, null, null)
        } else {
            try { resolver.delete(uri, null, null) } catch (e: Exception) { }
        }
    }
    uri
}

/** Scans done: join the other phone, fetch the list, and download it all as fast as the link allows. */
suspend fun startReceive(ctx: Context, code: String) {
    val j = parseJoin(code)
    if (j == null) {
        P2p.rxMsg = "That code is not from WaveLink."
        return
    }
    P2p.resetReceiver()
    P2p.rxActive = true
    P2p.rxMsg = "Looking for the other phone..."
    val wm = ctx.applicationContext.getSystemService(WifiManager::class.java)
    val lock = try { wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "wavelink:rx").also { it.acquire() } } catch (e: Exception) { null }
    val cm = ctx.getSystemService(ConnectivityManager::class.java)
    var net: Network? = null
    try {
        val near = withContext(Dispatchers.IO) { reach(j.host, j.fast, 1200, null) }
        if (!near) {
            if (j.ssid.isEmpty()) {
                P2p.rxMsg = "Cannot reach the other phone. Put both phones on the same Wi-Fi."
                return
            }
            P2p.rxMsg = "Joining the other phone. If Android asks, tap Connect."
            net = joinWifi(ctx, j)
            if (net == null) {
                P2p.rxMsg = "Could not join. Keep the code showing on the other phone and try again."
                return
            }
        }
        P2p.rxMsg = "Getting the list..."
        val list = withContext(Dispatchers.IO) { fetchItems(j, net) }
        if (list.isEmpty()) {
            P2p.rxMsg = "The other phone has not chosen anything yet."
            return
        }
        P2p.rxFiles = list.size
        P2p.rxTotal = list.sumOf { if (it.size > 0) it.size else 0L }
        P2p.rxMsg = "Receiving"
        val sem = Semaphore(3)
        val f = net
        coroutineScope {
            list.map { r ->
                async {
                    sem.withPermit {
                        try {
                            val uri = downloadOne(ctx, j, f, r)
                            P2p.fileDone()
                            withContext(Dispatchers.Main) {
                                Hub.received.add(0, Got(r.name, r.size, System.currentTimeMillis(), uri))
                            }
                        } catch (e: Exception) {
                            P2p.fileFailed()
                        }
                    }
                }
            }.awaitAll()
        }
        P2p.rxMsg = if (P2p.rxFailed == 0) "Done. Saved in Downloads/WaveLink" else "Done, but ${P2p.rxFailed} did not arrive."
    } catch (e: Exception) {
        P2p.rxMsg = "Stopped. Try scanning again."
    } finally {
        try { lock?.release() } catch (e: Exception) { }
        val c = P2p.cb
        if (c != null) {
            try { cm.unregisterNetworkCallback(c) } catch (e: Exception) { }
            P2p.cb = null
        }
        P2p.rxActive = false
    }
}
