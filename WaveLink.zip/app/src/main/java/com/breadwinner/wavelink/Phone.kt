package com.breadwinner.wavelink

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun PhonePage(onBack: () -> Unit, openLibrary: () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        SubHeader("Phone to phone", onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            SendCard(openLibrary)
            ReceiveCard()
            RCard(Modifier.fillMaxWidth()) {
                T("Why it is fast", 13, Muted)
                Spacer(Modifier.height(4.dp))
                T(
                    "The sender makes a private Wi-Fi link just for the two phones, on 5 GHz when the phone allows it. " +
                        "No router, no internet, no data. The QR code carries the name and password so nobody types anything. " +
                        "Bluetooth is only about 2 Mbps in real life, so it is not used for the files. " +
                        "Big files travel in four pieces at once.",
                    12, TextC, FontWeight.Medium
                )
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

private fun summary(): String {
    if (Hub.items.isEmpty()) return "Nothing chosen yet"
    val apps = Hub.items.count { it.kind == "app" }
    val files = Hub.items.size - apps
    val parts = ArrayList<String>()
    if (files > 0) parts.add(if (files == 1) "1 file" else "$files files")
    if (apps > 0) parts.add(if (apps == 1) "1 app" else "$apps apps")
    return parts.joinToString(" and ") + "  " + fmtSize(Hub.items.sumOf { if (it.size > 0) it.size else 0L })
}

@Composable
private fun SendCard(openLibrary: () -> Unit) {
    val ctx = LocalContext.current
    val start: () -> Unit = {
        ContextCompat.startForegroundService(
            ctx, Intent(ctx, ShareService::class.java).putExtra("mode", Hub.mode).putExtra("p2p", true)
        )
    }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { start() }
    val begin: () -> Unit = {
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
            need.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        } else {
            need.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        val missing = need.filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) start() else perms.launch(missing.toTypedArray())
    }

    var mbs by remember { mutableStateOf(0.0) }
    LaunchedEffect(P2p.on) {
        var last = P2p.sent.get()
        var t0 = System.nanoTime()
        while (P2p.on) {
            delay(500)
            val now = P2p.sent.get()
            val t = System.nanoTime()
            mbs = (now - last) / 1e6 / ((t - t0) / 1e9)
            last = now
            t0 = t
        }
        mbs = 0.0
    }
    val flash = remember { Animatable(0f) }
    LaunchedEffect(Hub.sendEndAt) {
        if (Hub.sendEndAt > 0 && Hub.sendOk && System.currentTimeMillis() - Hub.sendEndAt < 1500) {
            flash.snapTo(1f)
            flash.animateTo(0f, tween(900))
        }
    }

    RCard(Modifier.fillMaxWidth()) {
        T("Send", 19, weight = FontWeight.Bold)
        T(summary(), 12, Muted, FontWeight.Medium)
        Spacer(Modifier.height(12.dp))
        if (P2p.on) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                if (P2p.qr.isNotEmpty()) {
                    Box(
                        Modifier.shadow(10.dp, RoundedCornerShape(24.dp), ambientColor = Color(0x331E2D50), spotColor = Color(0x331E2D50))
                            .clip(RoundedCornerShape(24.dp))
                            .background(Brush.verticalGradient(listOf(Color.White, Color(0xFFDCE2EB))))
                            .padding(14.dp)
                    ) { Qr(P2p.qr, 220.dp) }
                } else {
                    Box(Modifier.height(120.dp), contentAlignment = Alignment.Center) {
                        T(P2p.msg.ifEmpty { "Making the fast link..." }, 13, Muted, FontWeight.Medium)
                    }
                }
            }
            if (P2p.qr.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    ShineButton(true, Hub.sendOn, false, flash.value, 0.62f) { }
                }
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    T(
                        if (Hub.sendOn) "Sending  " + String.format("%.0f", mbs) + " MB/s"
                        else "On the other phone: tap Receive and scan this code",
                        13, if (Hub.sendOn) Acc else Muted, FontWeight.SemiBold
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Pill("Choose more", false) { openLibrary() }
                Pill("Stop") { ctx.stopService(Intent(ctx, ShareService::class.java)) }
            }
        } else if (Hub.running) {
            T("Stop sharing on the home screen first, then come back.", 12, Orange, FontWeight.Medium)
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Pill("Choose things", false) { openLibrary() }
                Pill("Show QR code") { if (Hub.items.isEmpty()) openLibrary() else begin() }
            }
        }
    }
}

@Composable
private fun ReceiveCard() {
    val ctx = LocalContext.current
    val view = LocalView.current
    var mbs by remember { mutableStateOf(0.0) }
    var frac by remember { mutableStateOf(0f) }
    DisposableEffect(P2p.rxActive) {
        view.keepScreenOn = P2p.rxActive
        onDispose { view.keepScreenOn = false }
    }
    LaunchedEffect(P2p.rxActive) {
        var last = P2p.rxBytes.get()
        var t0 = System.nanoTime()
        while (P2p.rxActive) {
            delay(400)
            val now = P2p.rxBytes.get()
            val t = System.nanoTime()
            mbs = (now - last) / 1e6 / ((t - t0) / 1e9)
            last = now
            t0 = t
            frac = if (P2p.rxTotal > 0) (now.toFloat() / P2p.rxTotal).coerceIn(0f, 1f) else 0f
        }
        mbs = 0.0
        if (P2p.rxFiles > 0) frac = 1f
    }
    val flash = remember { Animatable(0f) }
    LaunchedEffect(P2p.rxDone) {
        if (P2p.rxDone > 0) {
            flash.snapTo(1f)
            flash.animateTo(0f, tween(700))
        }
    }
    var scanMsg by remember { mutableStateOf("") }
    val scan: () -> Unit = {
        scanMsg = ""
        try {
            val opts = GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
            GmsBarcodeScanning.getClient(ctx, opts).startScan()
                .addOnSuccessListener { b ->
                    val raw = b.rawValue ?: ""
                    P2p.scope.launch { startReceive(ctx.applicationContext, raw) }
                }
                .addOnFailureListener {
                    scanMsg = "The scanner could not open. It needs Google Play services."
                }
        } catch (e: Exception) {
            scanMsg = "The scanner could not open. It needs Google Play services."
        }
    }

    RCard(Modifier.fillMaxWidth()) {
        T("Receive", 19, weight = FontWeight.Bold)
        T("Scan the code on the other phone", 12, Muted, FontWeight.Medium)
        Spacer(Modifier.height(12.dp))
        if (P2p.rxActive || P2p.rxFiles > 0) {
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                ShineButton(P2p.rxActive, false, P2p.rxActive && P2p.rxMsg == "Receiving", flash.value, 0.62f) { }
            }
            // slim glass progress bar
            Box(
                Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Track)
            ) {
                Box(
                    Modifier.fillMaxWidth(frac).height(8.dp).clip(RoundedCornerShape(4.dp))
                        .background(Brush.horizontalGradient(listOf(Acc, Color(0xFF8FB0E6))))
                )
            }
            Spacer(Modifier.height(8.dp))
            T(
                if (P2p.rxFiles > 0) "${P2p.rxDone} of ${P2p.rxFiles} files" +
                    (if (P2p.rxActive) "  " + String.format("%.0f", mbs) + " MB/s" else "") else "",
                13, Acc, FontWeight.SemiBold
            )
        }
        if (P2p.rxMsg.isNotEmpty()) {
            T(P2p.rxMsg, 12, if (P2p.rxFailed > 0) Orange else Muted, FontWeight.Medium)
        }
        if (scanMsg.isNotEmpty()) T(scanMsg, 12, Orange, FontWeight.Medium)
        Spacer(Modifier.height(12.dp))
        if (!P2p.rxActive) Pill("Scan QR code") { scan() }
    }
}
