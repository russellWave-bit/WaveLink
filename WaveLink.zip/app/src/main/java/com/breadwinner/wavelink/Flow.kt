package com.breadwinner.wavelink

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.concurrent.atomic.AtomicLong

/** One line in the transfers list. state: 0 waiting, 1 moving, 2 done. */
class FlowLine(val name: String, val up: Boolean, val state: Int, val size: Long)

private class FlowRow(val name: String, val up: Boolean) {
    var size = 0L
    var active = 0
    var done = false
}

/**
 * One overall picture of everything moving, both ways, all files together.
 * The screens show a single bar from this, with the speed and the time left.
 */
object Flow {
    private val total = AtomicLong(0)
    private val done = AtomicLong(0)
    private val rows = LinkedHashMap<String, FlowRow>()
    private var finishedAt = 0L
    private var idleSince = 0L
    private var lastDone = 0L
    private var lastT = 0L
    private var lastUp = 0L
    private var lastDn = 0L

    var on by mutableStateOf(false)
    var frac by mutableStateOf(0f)
    var doneBytes by mutableStateOf(0L)
    var totalBytes by mutableStateOf(0L)
    var mbs by mutableStateOf(0f)
    var upMbs by mutableStateOf(0f)
    var dnMbs by mutableStateOf(0f)
    /** Seconds left, or -1 while it is still working it out. */
    var eta by mutableStateOf(-1)
    var finished by mutableStateOf(false)
    /** Goes up by one every time a batch finishes. The screens splash on it. */
    var burst by mutableStateOf(0)
    var lines by mutableStateOf(listOf<FlowLine>())

    private fun key(name: String, up: Boolean) = (if (up) "u:" else "d:") + name

    @Synchronized
    private fun fresh() {
        if (finishedAt != 0L) {
            total.set(0)
            done.set(0)
            rows.clear()
            finishedAt = 0L
            mbs = 0f
            lastDone = 0L
        }
    }

    @Synchronized
    fun begin(name: String, up: Boolean, len: Long) {
        fresh()
        val r = rows.getOrPut(key(name, up)) { FlowRow(name, up) }
        r.active++
        r.size += len
        r.done = false
        idleSince = 0L
        total.addAndGet(len)
    }

    fun bytes(n: Long) {
        done.addAndGet(n)
    }

    @Synchronized
    fun end(name: String, up: Boolean, ok: Boolean) {
        val r = rows[key(name, up)] ?: return
        r.active--
        if (r.active <= 0) {
            r.active = 0
            if (ok) r.done = true
        }
    }

    /** Called about twice a second from the app. Works out the percent, the speed and the time left. */
    @Synchronized
    fun tick() {
        val now = System.currentTimeMillis()
        val up = P2p.sent.get()
        val dn = Hub.rxBytes.get()
        if (lastT == 0L) {
            lastT = now
            lastUp = up
            lastDn = dn
        }
        val dt = (now - lastT) / 1000f
        if (dt >= 0.4f) {
            val u = (up - lastUp) / 1e6f / dt
            val d = (dn - lastDn) / 1e6f / dt
            upMbs = if (u > 0.05f) upMbs * 0.4f + u * 0.6f else 0f
            dnMbs = if (d > 0.05f) dnMbs * 0.4f + d * 0.6f else 0f
            val t0 = total.get()
            val dd = minOf(done.get(), t0)
            val inst = (dd - lastDone) / 1e6f / dt
            mbs = if (inst > 0.05f) (if (mbs <= 0f) inst else mbs * 0.6f + inst * 0.4f) else 0f
            lastDone = dd
            lastT = now
            lastUp = up
            lastDn = dn
        }
        val t = total.get()
        if (t <= 0L) {
            if (on) on = false
            if (lines.isNotEmpty()) lines = emptyList()
            frac = 0f
            finished = false
            return
        }
        val d = minOf(done.get(), t)
        val busy = rows.values.any { it.active > 0 }
        if (finishedAt == 0L) {
            if (!busy) {
                if (idleSince == 0L) idleSince = now
                // everything came in, or nothing moved for a while: call it finished
                if (d >= t || now - idleSince > 8000) {
                    finishedAt = now
                    burst += 1
                    for (r in rows.values) if (r.active == 0 && d >= t) r.done = true
                }
            } else {
                idleSince = 0L
            }
        }
        on = true
        finished = finishedAt != 0L
        frac = if (finished && d >= t) 1f else d.toFloat() / t
        doneBytes = d
        totalBytes = t
        eta = if (!finished && mbs > 0.05f) ((t - d) / 1e6f / mbs).toInt() else -1
        lines = rows.values.toList().takeLast(60).map {
            FlowLine(it.name, it.up, if (it.done) 2 else if (it.active > 0) 1 else 0, it.size)
        }.reversed()
        if (finishedAt != 0L && now - finishedAt > 25000) {
            total.set(0)
            done.set(0)
            rows.clear()
            finishedAt = 0L
            on = false
            finished = false
            frac = 0f
        }
    }
}

fun fmtEta(s: Int): String = when {
    s < 0 -> "Working out the time left"
    s < 2 -> "Almost there"
    s < 60 -> "About $s s left"
    s < 3600 -> "About ${s / 60} min ${s % 60} s left"
    else -> "About ${s / 3600} h ${(s % 3600) / 60} min left"
}
