package com.breadwinner.wavelink

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.net.wifi.WifiManager
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager

/** Keeps the web server (and the optional temporary hotspot) alive while sharing. */
class ShareService : Service() {
    private var server: ShareServer? = null
    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null
    private var lock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var fast: FastServer? = null
    private var p2pManager: WifiP2pManager? = null
    private var p2pCh: WifiP2pManager.Channel? = null
    private val main = Handler(Looper.getMainLooper())

    companion object {
        const val STOP = "wavelink.stop"
        const val CH = "share"
    }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Sharing", NotificationManager.IMPORTANCE_LOW))
        startForeground(1, notif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)

        if (server == null) startServer()
        if (lock == null) {
            val pm = getSystemService(PowerManager::class.java)
            lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "wavelink:transfer").apply { acquire() }
        }
        Hub.running = server != null
        if (server == null) {
            Hub.hotspotMsg = "Could not start the sharing server."
            stopSelf()
            return START_NOT_STICKY
        }
        Hub.mode = i?.getIntExtra("mode", 0) ?: 0
        val p2p = i?.getBooleanExtra("p2p", false) ?: false
        if (wifiLock == null) {
            try {
                val wm = applicationContext.getSystemService(WifiManager::class.java)
                wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "wavelink:link").also { it.acquire() }
            } catch (e: Exception) {
            }
        }
        if (p2p) {
            if (!P2p.on) startDirect()
        } else if (Hub.mode == 1 && reservation == null) {
            startHotspot()
        }
        return START_NOT_STICKY
    }

    private fun notif(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(
            this, 1, Intent(this, ShareService::class.java).setAction(STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("WaveLink is on")
            .setContentText("Open the address on your PC")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "Stop", stop).build())
            .build()
    }

    private fun startServer() {
        for (p in 8080..8090) {
            try {
                val s = ShareServer(p, applicationContext)
                s.start()
                server = s
                Hub.port = p
                return
            } catch (e: Exception) {
            }
        }
    }


    // ───── phone to phone: a private Wi-Fi Direct link on 5 GHz, with a name and password the QR code carries ─────

    private fun publish(ssid: String, pass: String, host: String) {
        P2p.qr = P2p.makeQr(ssid, pass, host, fast?.port ?: 8180)
        P2p.msg = ""
    }

    private fun randomText(n: Int): String {
        val chars = "abcdefghjkmnpqrstuvwxyz23456789"
        val rnd = java.security.SecureRandom()
        val sb = StringBuilder()
        for (k in 0 until n) sb.append(chars[rnd.nextInt(chars.length)])
        return sb.toString()
    }

    @SuppressLint("MissingPermission")
    private fun startDirect() {
        P2p.resetSender()
        P2p.on = true
        P2p.msg = "Making the fast link..."
        val f = FastServer(applicationContext)
        if (f.start()) fast = f
        if (reservation != null) {
            // a hotspot is already running, just share it
            publish(Hub.ssid, Hub.pass, findIp(1)?.first ?: "192.168.43.1")
            return
        }
        val wp = getSystemService(WifiP2pManager::class.java)
        if (wp == null) {
            fallbackHotspot()
            return
        }
        p2pManager = wp
        val ch = try { wp.initialize(this, Looper.getMainLooper(), null) } catch (e: Exception) { null }
        if (ch == null) {
            fallbackHotspot()
            return
        }
        p2pCh = ch
        val name = "DIRECT-WL-" + randomText(4)
        val pass = randomText(10)

        fun make(band: Int) {
            try {
                val cfg = WifiP2pConfig.Builder()
                    .setNetworkName(name)
                    .setPassphrase(pass)
                    .enablePersistentMode(false)
                    .setGroupOperatingBand(band)
                    .build()
                wp.createGroup(ch, cfg, object : WifiP2pManager.ActionListener {
                    override fun onSuccess() {
                        waitGroup(wp, ch, name, pass, 0)
                    }

                    override fun onFailure(reason: Int) {
                        if (band == WifiP2pConfig.GROUP_OWNER_BAND_5GHZ) make(WifiP2pConfig.GROUP_OWNER_BAND_AUTO)
                        else fallbackHotspot()
                    }
                })
            } catch (e: Exception) {
                fallbackHotspot()
            }
        }

        try {
            wp.removeGroup(ch, object : WifiP2pManager.ActionListener {
                override fun onSuccess() { make(WifiP2pConfig.GROUP_OWNER_BAND_5GHZ) }
                override fun onFailure(reason: Int) { make(WifiP2pConfig.GROUP_OWNER_BAND_5GHZ) }
            })
        } catch (e: Exception) {
            make(WifiP2pConfig.GROUP_OWNER_BAND_5GHZ)
        }
    }

    @SuppressLint("MissingPermission")
    private fun waitGroup(wp: WifiP2pManager, ch: WifiP2pManager.Channel, name: String, pass: String, tries: Int) {
        try {
            wp.requestGroupInfo(ch) { g ->
                if (g != null && g.isGroupOwner) {
                    wp.requestConnectionInfo(ch) { info ->
                        val host = info?.groupOwnerAddress?.hostAddress ?: "192.168.49.1"
                        publish(g.networkName ?: name, g.passphrase ?: pass, host)
                    }
                } else if (tries < 14) {
                    main.postDelayed({ waitGroup(wp, ch, name, pass, tries + 1) }, 400)
                } else {
                    fallbackHotspot()
                }
            }
        } catch (e: Exception) {
            fallbackHotspot()
        }
    }

    private fun fallbackHotspot() {
        if (!P2p.on || P2p.qr.isNotEmpty()) return
        P2p.msg = "Using the hotspot link..."
        if (reservation == null) startHotspot()
    }

    @Suppress("DEPRECATION")
    private fun startHotspot() {
        Hub.hotspotMsg = "Starting the hotspot..."
        val wm = applicationContext.getSystemService(WifiManager::class.java)
        try {
            wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                    reservation = r
                    if (Build.VERSION.SDK_INT >= 30) {
                        val c = r.softApConfiguration
                        Hub.ssid = c.ssid ?: ""
                        Hub.pass = c.passphrase ?: ""
                    } else {
                        val c = r.wifiConfiguration
                        Hub.ssid = (c?.SSID ?: "").trim('"')
                        Hub.pass = c?.preSharedKey ?: ""
                    }
                    Hub.hotspotMsg = ""
                    if (P2p.on && P2p.qr.isEmpty()) {
                        main.postDelayed({
                            val ip = findIp(1)?.first ?: "192.168.43.1"
                            publish(Hub.ssid, Hub.pass, ip)
                        }, 1500)
                    }
                }

                override fun onStopped() {
                    Hub.ssid = ""
                    Hub.pass = ""
                    Hub.hotspotMsg = "The hotspot stopped."
                }

                override fun onFailed(reason: Int) {
                    Hub.hotspotMsg = when (reason) {
                        ERROR_NO_CHANNEL -> "No Wi-Fi channel is free right now. Try again."
                        ERROR_INCOMPATIBLE_MODE -> "Turn off your normal hotspot first, then try again."
                        ERROR_TETHERING_DISALLOWED -> "This phone does not allow apps to start a hotspot."
                        else -> "The hotspot could not start. Make sure Location is switched on."
                    }
                }
            }, Handler(Looper.getMainLooper()))
        } catch (e: SecurityException) {
            Hub.hotspotMsg = "Allow the permission and switch Location on, then try again."
        } catch (e: Exception) {
            Hub.hotspotMsg = "The hotspot could not start on this phone."
        }
    }

    override fun onDestroy() {
        try { reservation?.close() } catch (e: Exception) { }
        reservation = null
        try {
            val c = p2pCh
            if (c != null) p2pManager?.removeGroup(c, null)
        } catch (e: Exception) { }
        p2pCh = null
        try { fast?.stop() } catch (e: Exception) { }
        fast = null
        try { wifiLock?.release() } catch (e: Exception) { }
        wifiLock = null
        P2p.resetSender()
        try { server?.stop() } catch (e: Exception) { }
        server = null
        try { lock?.release() } catch (e: Exception) { }
        lock = null
        Hub.running = false
        Hub.ssid = ""
        Hub.pass = ""
        Hub.clearSeen()
        Hub.resetProgress()
        super.onDestroy()
    }
}
