package com.breadwinner.wavelink

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

// Silver glass: pale polished metal, frosted panes, one steel-blue accent.
val Bg = Color(0xFFEEF1F6)
val BgBot = Color(0xFFC9D0DB)
val CardC = Color(0xFFFFFFFF)
val TextC = Color(0xFF1E232B)
val Muted = Color(0xFF68727F)
val Acc = Color(0xFF3F6FB5)
val Track = Color(0xFFD3D9E3)
val Orange = Color(0xFFB4501C)
val OnAcc = Color(0xFF1E232B)
val Sand = Color(0xFF3F6FB5)
val Teal = Color(0xFF2E8B7A)
val Hair = Color(0x331E232B)
val Shine = Color(0xFFFFFFFF)

enum class Pg { Home, Mode, Share, Received, Tips, Phone }

@Composable
fun T(
    text: String, size: Int = 13, color: Color = TextC,
    weight: FontWeight = FontWeight.SemiBold, modifier: Modifier = Modifier, maxLines: Int = Int.MAX_VALUE
) {
    Text(
        text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier,
        maxLines = maxLines, overflow = TextOverflow.Ellipsis
    )
}

/** Polished silver sky behind every page. */
fun Modifier.sky(): Modifier = this
    .background(Brush.verticalGradient(listOf(Bg, BgBot)))
    .drawBehind {
        drawCircle(
            Brush.radialGradient(listOf(Color(0xCCFFFFFF), Color.Transparent), Offset(size.width * 0.15f, size.height * 0.08f), size.width * 0.9f),
            size.width * 0.9f, Offset(size.width * 0.15f, size.height * 0.08f)
        )
        drawCircle(
            Brush.radialGradient(listOf(Color(0x99FFFFFF), Color.Transparent), Offset(size.width * 0.95f, size.height * 0.92f), size.width),
            size.width, Offset(size.width * 0.95f, size.height * 0.92f)
        )
    }

/** A pane of frosted glass. */
@Composable
fun RCard(modifier: Modifier = Modifier, bg: Color = Color.Transparent, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    var m = modifier.shadow(8.dp, shape, ambientColor = Color(0x331E2D50), spotColor = Color(0x331E2D50))
        .clip(shape)
        .background(Brush.verticalGradient(listOf(Color(0xE6FFFFFF), Color(0xB3FFFFFF))))
        .background(bg)
        .border(1.dp, Brush.verticalGradient(listOf(Color.White, Color(0x55FFFFFF))), shape)
    if (onClick != null) m = m.clickable { onClick() }
    Column(m.padding(16.dp)) { content() }
}

@Composable
fun Pill(text: String, filled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val m = if (filled) {
        Modifier.shadow(6.dp, shape, ambientColor = Color(0x551E2D50), spotColor = Color(0x551E2D50))
            .clip(shape)
            .background(Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0xFFD3D9E3), Color(0xFFE6EAF0))))
            .border(1.dp, Color.White, shape)
    } else {
        Modifier.clip(shape).background(Color(0xB3FFFFFF)).border(1.dp, Hair, shape)
    }
    Box(
        Modifier.padding(bottom = 3.dp).then(m).clickable { onClick() }.padding(horizontal = 18.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) { T(text, 13, TextC) }
}

@Composable
fun Qr(text: String, dp: Dp) {
    val m = remember(text) {
        try {
            QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, mapOf(EncodeHintType.MARGIN to 1))
        } catch (e: Exception) {
            null
        }
    }
    Canvas(Modifier.size(dp).clip(RoundedCornerShape(6.dp)).background(Color.White)) {
        if (m != null) {
            val cell = this.size.width / m.width
            for (y in 0 until m.height) {
                for (x in 0 until m.width) {
                    if (m.get(x, y)) drawRect(Color.Black, Offset(x * cell, y * cell), Size(cell + 0.6f, cell + 0.6f))
                }
            }
        }
    }
}

private fun wifiEsc(s: String): String =
    s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace(":", "\\:").replace("\"", "\\\"")

fun openTethering(c: Context) {
    val tries = listOf(
        Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"),
        Intent(Settings.ACTION_WIRELESS_SETTINGS)
    )
    for (i in tries) {
        try {
            c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        } catch (e: Exception) {
        }
    }
}

// ───────────────────────── ROOT ─────────────────────────

@Composable
fun WaveLinkApp() {
    var pg by remember { mutableStateOf(Pg.Home) }
    var prev by remember { mutableStateOf(Pg.Home) }
    fun nav(t: Pg) {
        prev = pg
        pg = t
    }

    BackHandler(pg != Pg.Home) {
        pg = if (pg == Pg.Share) prev else Pg.Home
    }

    val req = Hub.pairReq
    if (req != null) {
        AlertDialog(
            onDismissRequest = { Hub.pairAnswer = 2 },
            title = { Text(req.name + " wants to connect") },
            text = { Text("Allow this PC to send files to your phone and fetch the files you share. Only say yes if it is your own PC.") },
            confirmButton = { TextButton(onClick = { Hub.pairAnswer = 1 }) { Text("Allow") } },
            dismissButton = { TextButton(onClick = { Hub.pairAnswer = 2 }) { Text("Not now") } }
        )
    }

    Box(Modifier.fillMaxSize().sky()) {
        when (pg) {
            Pg.Home -> HomePage { nav(it) }
            Pg.Mode -> ModePage { pg = Pg.Home }
            Pg.Share -> LibraryPage { pg = prev }
            Pg.Received -> ReceivedPage { pg = Pg.Home }
            Pg.Tips -> TipsPage { pg = Pg.Home }
            Pg.Phone -> PhonePage({ pg = Pg.Home }, { nav(Pg.Share) })
        }
    }
}

fun Modifier.glassDot(): Modifier = this
    .shadow(6.dp, CircleShape, ambientColor = Color(0x331E2D50), spotColor = Color(0x331E2D50))
    .clip(CircleShape)
    .background(Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0xFFDDE2EA))))
    .border(1.dp, Color.White, CircleShape)

@Composable
fun SubHeader(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).glassDot().clickable { onBack() },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(22.dp)) {
                val w = 2.5.dp.toPx()
                drawLine(TextC, Offset(size.width * 0.62f, size.height * 0.2f), Offset(size.width * 0.32f, size.height * 0.5f), w, StrokeCap.Round)
                drawLine(TextC, Offset(size.width * 0.32f, size.height * 0.5f), Offset(size.width * 0.62f, size.height * 0.8f), w, StrokeCap.Round)
            }
        }
        Spacer(Modifier.width(12.dp))
        T(title, 22, weight = FontWeight.Bold)
    }
}

// ───────────────────────── HOME ─────────────────────────

/**
 * The big round button: a polished silver disc under glass.
 * While sharing, light rings flow OUT of it for files going to the PC
 * and IN to it for files coming from the PC. A shine sweeps over it when a file lands.
 */
@Composable
fun ShineButton(running: Boolean, sendOn: Boolean, recvOn: Boolean, flash: Float, zoom: Float = 1f, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "wl")
    val flow by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2200, easing = LinearEasing)), label = "f")
    val spin by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "s")
    val breathe by inf.animateFloat(0f, 6.2831855f, infiniteRepeatable(tween(4000, easing = LinearEasing)), label = "b")
    Box(Modifier.size(330.dp * zoom), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
          val u = size.width / 330.dp.toPx()
          scale(u, u, Offset.Zero) {
            val c = Offset(165.dp.toPx(), 165.dp.toPx())
            val r = 100.dp.toPx()
            val reach = 58.dp.toPx()

            // soft resting rings
            for (k in 0..2) {
                drawCircle(
                    Color(0xFF1E2D50).copy(alpha = 0.07f - 0.02f * k), r + (14 + k * 16).dp.toPx(), c,
                    style = Stroke(1.dp.toPx())
                )
            }

            // flowing rings: out = sending to PC, in = receiving from PC
            fun rings(color: Color, outward: Boolean) {
                for (k in 0..3) {
                    val ph = (flow + k / 4f) % 1f
                    val d = if (outward) ph else 1f - ph
                    val rad = r + 8.dp.toPx() + d * reach
                    val a = (sin(ph * 3.1415927f)).coerceIn(0f, 1f) * 0.55f
                    drawCircle(color.copy(alpha = a), rad, c, style = Stroke(2.dp.toPx()))
                    drawCircle(color.copy(alpha = a * 0.25f), rad, c, style = Stroke(7.dp.toPx()))
                }
                // little packets riding the flow
                for (n in 0 until 10) {
                    val ang = (n / 10f) * 6.2831855f + (if (outward) 0f else 0.31f)
                    val ph = (flow * 1.0f + (n % 5) / 5f) % 1f
                    val d = if (outward) ph else 1f - ph
                    val rad = r + 8.dp.toPx() + d * reach
                    val a = (sin(ph * 3.1415927f)).coerceIn(0f, 1f)
                    drawCircle(color.copy(alpha = a * 0.9f), 2.6.dp.toPx(), Offset(c.x + rad * cos(ang), c.y + rad * sin(ang)))
                }
            }
            if (running && sendOn) rings(Acc, true)
            if (running && recvOn) rings(Teal, false)

            // idle glow ring when shared but quiet
            if (running && !sendOn && !recvOn) {
                drawCircle(Acc.copy(alpha = 0.18f + 0.1f * sin(breathe)), r + 12.dp.toPx(), c, style = Stroke(3.dp.toPx()))
            }

            // shadow under the disc
            for (k in 0..5) {
                drawCircle(Color(0xFF1E2D50).copy(alpha = 0.05f), r + (3 + k * 3).dp.toPx(), Offset(c.x, c.y + (8 + k).dp.toPx()))
            }

            // the polished silver disc: a turning metal sheen
            val metal = listOf(
                Color(0xFFFAFBFD), Color(0xFFB7BFCB), Color(0xFFF1F4F8), Color(0xFF98A2B0),
                Color(0xFFFAFBFD), Color(0xFFC3CAD5), Color(0xFFFFFFFF), Color(0xFFA6AFBC), Color(0xFFFAFBFD)
            )
            rotate(if (running) spin else 30f, c) {
                drawCircle(Brush.sweepGradient(metal, c), r, c)
            }
            // rim
            drawCircle(Color.White.copy(alpha = 0.9f), r, c, style = Stroke(2.dp.toPx()))
            drawCircle(Color(0xFF6B7684).copy(alpha = 0.35f), r - 1.dp.toPx(), c, style = Stroke(1.dp.toPx()))
            // glass dome on top
            drawCircle(
                Brush.radialGradient(
                    listOf(Color(0x55FFFFFF), Color(0x00FFFFFF), Color(0x22000000)),
                    Offset(c.x - r * 0.3f, c.y - r * 0.45f), r * 1.3f
                ), r - 3.dp.toPx(), c
            )
            // specular highlight
            drawOval(
                Brush.verticalGradient(listOf(Color(0xDDFFFFFF), Color(0x00FFFFFF)), c.y - r * 0.92f, c.y - r * 0.1f),
                Offset(c.x - r * 0.62f, c.y - r * 0.92f), Size(r * 1.24f, r * 0.8f)
            )

            // a shine pulse when a file finishes
            if (flash > 0f) {
                drawCircle(Color.White.copy(alpha = flash * 0.9f), r, c)
                drawCircle(Acc.copy(alpha = flash * 0.5f), r + (1f - flash) * 40.dp.toPx(), c, style = Stroke(3.dp.toPx()))
            }

            // symbol: arrow down to start, square to stop
            val w = 6.dp.toPx()
            val sz = 58.dp.toPx()
            val x0 = c.x - sz / 2
            val y0 = c.y - sz / 2
            val ink = Color(0xFF2A313B)
            if (running) {
                drawRoundRect(ink, Offset(x0 + sz * 0.2f, y0 + sz * 0.2f), Size(sz * 0.6f, sz * 0.6f), CornerRadius(5.dp.toPx()))
            } else {
                drawLine(ink, Offset(c.x, y0 + sz * 0.08f), Offset(c.x, y0 + sz * 0.86f), w, StrokeCap.Round)
                drawLine(ink, Offset(x0 + sz * 0.18f, y0 + sz * 0.56f), Offset(c.x, y0 + sz * 0.88f), w, StrokeCap.Round)
                drawLine(ink, Offset(x0 + sz * 0.82f, y0 + sz * 0.56f), Offset(c.x, y0 + sz * 0.88f), w, StrokeCap.Round)
            }
          }
        }
        Box(Modifier.size(210.dp * zoom).clip(CircleShape).clickable { onClick() })
    }
}

/**
 * The stage: your phone on the left, your PC on the right, and two wave strands that cross between them.
 * Blue packets ride the upper strand to the PC, green packets ride the lower strand to the phone.
 * Both can run at the same time. While no PC is linked the strands march slowly, looking for one.
 */
@Composable
fun LinkStage(flash: Float) {
    val inf = rememberInfiniteTransition(label = "stage")
    val t by inf.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "t")
    val drift by inf.animateFloat(0f, 6.2831855f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "d")
    val linked = Hub.running && Hub.devices > 0
    val up = Hub.running && Hub.sendOn
    val down = Hub.running && Hub.recvOn
    val upA by animateFloatAsState(if (up) 1f else 0f, tween(450), label = "ua")
    val dnA by animateFloatAsState(if (down) 1f else 0f, tween(450), label = "da")
    val lk by animateFloatAsState(if (linked) 1f else 0f, tween(500), label = "lk")

    var upMb by remember { mutableStateOf(0f) }
    var dnMb by remember { mutableStateOf(0f) }
    LaunchedEffect(Hub.running) {
        var a = P2p.sent.get()
        var b = Hub.rxBytes.get()
        var tm = System.nanoTime()
        while (true) {
            delay(500)
            val na = P2p.sent.get()
            val nb = Hub.rxBytes.get()
            val nt = System.nanoTime()
            val dt = (nt - tm) / 1e9f
            val u = (na - a) / 1e6f / dt
            val d = (nb - b) / 1e6f / dt
            upMb = if (u > 0.05f) upMb * 0.4f + u * 0.6f else 0f
            dnMb = if (d > 0.05f) dnMb * 0.4f + d * 0.6f else 0f
            a = na; b = nb; tm = nt
        }
    }

    Column(Modifier.fillMaxWidth()) {
        Canvas(Modifier.fillMaxWidth().height(150.dp)) {
            val w = size.width
            val h = size.height
            val cy = h / 2f
            val ink = TextC
            val sw = 3.dp.toPx()

            // phone, left
            val pw = 46.dp.toPx(); val ph = 84.dp.toPx()
            val px = 6.dp.toPx(); val py = cy - ph / 2
            val glow = (flash * 0.9f).coerceIn(0f, 1f)
            drawRoundRect(Color.White.copy(alpha = 0.55f + glow * 0.4f), Offset(px, py), Size(pw, ph), CornerRadius(11.dp.toPx()))
            drawRoundRect(ink.copy(alpha = 0.85f), Offset(px, py), Size(pw, ph), CornerRadius(11.dp.toPx()), style = Stroke(sw))
            drawRoundRect(Teal.copy(alpha = 0.10f + 0.5f * dnA * (0.6f + 0.4f * sin(t * 6.2831855f * 2))), Offset(px + 6.dp.toPx(), py + 10.dp.toPx()), Size(pw - 12.dp.toPx(), ph - 20.dp.toPx()), CornerRadius(5.dp.toPx()))
            drawRoundRect(ink.copy(alpha = 0.7f), Offset(px + pw / 2 - 6.dp.toPx(), py + 4.dp.toPx()), Size(12.dp.toPx(), 2.dp.toPx()), CornerRadius(1.dp.toPx()))

            // PC, right: monitor on a stand
            val mw = 92.dp.toPx(); val mh = 62.dp.toPx()
            val mx = w - mw - 6.dp.toPx(); val my = cy - mh / 2 - 6.dp.toPx()
            drawRoundRect(Color.White.copy(alpha = 0.55f + glow * 0.4f), Offset(mx, my), Size(mw, mh), CornerRadius(8.dp.toPx()))
            drawRoundRect(ink.copy(alpha = 0.85f), Offset(mx, my), Size(mw, mh), CornerRadius(8.dp.toPx()), style = Stroke(sw))
            drawRoundRect(Acc.copy(alpha = 0.10f + 0.5f * upA * (0.6f + 0.4f * sin(t * 6.2831855f * 2))), Offset(mx + 6.dp.toPx(), my + 6.dp.toPx()), Size(mw - 12.dp.toPx(), mh - 12.dp.toPx()), CornerRadius(4.dp.toPx()))
            drawLine(ink.copy(alpha = 0.85f), Offset(mx + mw / 2, my + mh), Offset(mx + mw / 2, my + mh + 10.dp.toPx()), sw, StrokeCap.Round)
            drawLine(ink.copy(alpha = 0.85f), Offset(mx + mw / 2 - 18.dp.toPx(), my + mh + 11.dp.toPx()), Offset(mx + mw / 2 + 18.dp.toPx(), my + mh + 11.dp.toPx()), sw, StrokeCap.Round)
            // little dot: the PC is linked
            drawCircle(if (linked) Teal else Muted.copy(alpha = 0.5f), 5.dp.toPx(), Offset(mx + mw - 10.dp.toPx(), my - 2.dp.toPx()))
            drawCircle(Color.White, 5.dp.toPx(), Offset(mx + mw - 10.dp.toPx(), my - 2.dp.toPx()), style = Stroke(1.5.dp.toPx()))

            // the two strands
            val x0 = px + pw + 12.dp.toPx()
            val x1 = mx - 12.dp.toPx()
            val span = (x1 - x0).coerceAtLeast(1f)
            val amp = 26.dp.toPx()
            fun yAt(u: Float, sign: Float): Float =
                cy - 6.dp.toPx() + sign * amp * sin(3.1415927f * u) * sin(6.2831855f * u + drift)
            fun strand(color: Color, sign: Float, alpha: Float, dashed: Boolean) {
                val p = Path()
                val n = 60
                for (i in 0..n) {
                    val u = i / n.toFloat()
                    val x = x0 + span * u
                    val y = yAt(u, sign)
                    if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                }
                val eff = if (dashed) PathEffect.dashPathEffect(floatArrayOf(10.dp.toPx(), 12.dp.toPx()), -t * 44.dp.toPx()) else null
                drawPath(p, color.copy(alpha = alpha), style = Stroke(sw * 1.2f, cap = StrokeCap.Round, pathEffect = eff))
            }
            val searching = lk < 0.5f
            strand(Acc, 1f, if (searching) 0.35f else 0.28f + 0.72f * upA, searching)
            strand(Teal, -1f, if (searching) 0.35f else 0.28f + 0.72f * dnA, searching)

            // packets: out along the upper strand, in along the lower one
            fun packets(color: Color, sign: Float, toPc: Boolean, a: Float) {
                if (a < 0.02f) return
                val k = 7
                for (i in 0 until k) {
                    val ph2 = (t + i / k.toFloat()) % 1f
                    val u = if (toPc) ph2 else 1f - ph2
                    val x = x0 + span * u
                    val y = yAt(u, sign)
                    val al = (sin(3.1415927f * ph2)).coerceIn(0f, 1f) * a
                    drawRoundRect(color.copy(alpha = al), Offset(x - 7.dp.toPx(), y - 4.dp.toPx()), Size(14.dp.toPx(), 8.dp.toPx()), CornerRadius(4.dp.toPx()))
                    drawRoundRect(Color.White.copy(alpha = al * 0.9f), Offset(x - 7.dp.toPx(), y - 4.dp.toPx()), Size(14.dp.toPx(), 8.dp.toPx()), CornerRadius(4.dp.toPx()), style = Stroke(1.2.dp.toPx()))
                }
            }
            packets(Acc, 1f, true, upA)
            packets(Teal, -1f, false, dnA)
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            T("This phone", 12, Muted)
            T(if (linked) "Your PC" else "Looking for your PC", 12, if (linked) Teal else Muted)
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            SpeedChip("Phone to PC", if (up) String.format(Locale.US, "%.1f MB/s", upMb) else "idle", Acc, up)
            SpeedChip("PC to phone", if (down) String.format(Locale.US, "%.1f MB/s", dnMb) else "idle", Teal, down)
        }
    }
}

@Composable
private fun SpeedChip(label: String, value: String, color: Color, on: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(if (on) color else color.copy(alpha = 0.3f)))
        Spacer(Modifier.width(8.dp))
        Column {
            T(label, 11, Muted, FontWeight.Medium)
            T(value, 15, if (on) color else Muted, FontWeight.Bold)
        }
    }
}

@Composable
fun HomePage(go: (Pg) -> Unit) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    var ip by remember { mutableStateOf<Pair<String, String>?>(null) }

    LaunchedEffect(Hub.running, Hub.eff) {
        while (Hub.running) {
            ip = withContext(Dispatchers.Default) { findIp(Hub.eff) }
            Hub.recount()
            delay(2000)
        }
        ip = null
    }

    // shine when a file finishes
    val flash = remember { Animatable(0f) }
    LaunchedEffect(Hub.sendEndAt) {
        if (Hub.sendEndAt > 0 && System.currentTimeMillis() - Hub.sendEndAt < 1500 && Hub.sendOk) {
            flash.snapTo(1f)
            flash.animateTo(0f, tween(900))
        }
    }
    LaunchedEffect(Hub.recvEndAt) {
        if (Hub.recvEndAt > 0 && System.currentTimeMillis() - Hub.recvEndAt < 1500 && Hub.recvOk) {
            flash.snapTo(1f)
            flash.animateTo(0f, tween(900))
        }
    }

    val doStart: () -> Unit = {
        ContextCompat.startForegroundService(
            ctx, Intent(ctx, ShareService::class.java).putExtra("mode", Hub.mode)
        )
    }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { doStart() }
    val toggle: () -> Unit = {
        if (Hub.running) {
            ctx.stopService(Intent(ctx, ShareService::class.java))
        } else {
            val need = ArrayList<String>()
            val mayHotspot = Hub.mode == 1 || Hub.mode == 3
            if (Build.VERSION.SDK_INT >= 33) {
                need.add(Manifest.permission.POST_NOTIFICATIONS)
                if (mayHotspot) need.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            } else if (mayHotspot) {
                need.add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
            val missing = need.filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isEmpty()) doStart() else perms.launch(missing.toTypedArray())
        }
    }

    // open the app, and it starts looking for your PC by itself (once per launch)
    LaunchedEffect(Unit) {
        if (!Hub.autoTried && !Hub.running) {
            Hub.autoTried = true
            toggle()
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        // top: name on the left, three-dot menu on the right
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            T("WaveLink", 24, weight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Box {
                Box(
                    Modifier.size(44.dp).glassDot().clickable { menu = true },
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(Modifier.size(22.dp)) {
                        for (k in 0..2) drawCircle(TextC, 2.2.dp.toPx(), Offset(size.width / 2, size.height * (0.15f + 0.35f * k)))
                    }
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    DropdownMenuItem(text = { Text("Connection mode") }, onClick = { menu = false; go(Pg.Mode) })
                    DropdownMenuItem(text = { Text("Library") }, onClick = { menu = false; go(Pg.Share) })
                    DropdownMenuItem(text = { Text("Phone to phone") }, onClick = { menu = false; go(Pg.Phone) })
                    DropdownMenuItem(text = { Text("Received from PC") }, onClick = { menu = false; go(Pg.Received) })
                    DropdownMenuItem(text = { Text("Tips") }, onClick = { menu = false; go(Pg.Tips) })
                }
            }
        }

        Column(
            Modifier.weight(1f).fillMaxWidth().navigationBarsPadding().verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            RCard(Modifier.padding(horizontal = 16.dp).fillMaxWidth()) { LinkStage(flash.value) }

            Spacer(Modifier.height(4.dp))
            ShineButton(Hub.running, false, false, flash.value, zoom = 0.66f, onClick = toggle)

            // the library, as plain text under the button
            Column(
                Modifier.clip(RoundedCornerShape(10.dp)).clickable { go(Pg.Share) }.padding(horizontal = 24.dp, vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                T("Library", 22, weight = FontWeight.Bold)
                T(
                    if (Hub.items.isEmpty()) "Choose what to share" else "${Hub.items.size} chosen",
                    12, Muted, FontWeight.Medium
                )
            }

            Spacer(Modifier.height(6.dp))
            Pill("Phone to phone", false) { go(Pg.Phone) }

            if (Hub.sendOn) {
                T("Sending " + (Hub.sendP * 100).toInt() + "%  " + Hub.sendName, 12, Acc, maxLines = 1,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 2.dp))
            }
            if (Hub.recvOn) {
                T("Receiving " + (Hub.recvP * 100).toInt() + "%  " + Hub.recvName, 12, Teal, maxLines = 1,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 2.dp))
            }
            if (!Hub.running) {
                Spacer(Modifier.height(2.dp))
                T("Tap the button to start", 12, Muted, FontWeight.Medium)
            }
            if (Hub.hotspotMsg.isNotEmpty() && (Hub.eff == 1 || !Hub.running)) {
                Spacer(Modifier.height(8.dp))
                T(Hub.hotspotMsg, 13, Orange, modifier = Modifier.padding(horizontal = 24.dp))
            }

            if (Hub.running) {
                Spacer(Modifier.height(14.dp))
                AddressCard(ip)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
fun AddressCard(ip: Pair<String, String>?) {
    Column(
        Modifier.padding(horizontal = 16.dp).fillMaxWidth()
            .shadow(8.dp, RoundedCornerShape(20.dp), ambientColor = Color(0x331E2D50), spotColor = Color(0x331E2D50))
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.verticalGradient(listOf(Color(0xE6FFFFFF), Color(0xB3FFFFFF))))
            .border(1.dp, Brush.verticalGradient(listOf(Color.White, Color(0x55FFFFFF))), RoundedCornerShape(20.dp))
            .padding(18.dp)
    ) {
        if (Hub.eff == 1) {
            T("Join this Wi-Fi on the PC once", 11, Muted, FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            T("Wi-Fi name", 11, Muted, FontWeight.Medium)
            T(if (Hub.ssid.isNotEmpty()) Hub.ssid else "Starting...", 22, weight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            T("Password", 11, Muted, FontWeight.Medium)
            T(if (Hub.pass.isNotEmpty()) Hub.pass else "...", 22, Acc, FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
        }
        if (ip != null) {
            T(
                if (Hub.devices > 0) "PC linked" else "Open WaveLink PC on your computer",
                18, if (Hub.devices > 0) Teal else TextC, FontWeight.Bold
            )
            Spacer(Modifier.height(4.dp))
            T(
                if (Hub.devices > 0) "It found this phone by itself. Drop files on the PC app, or pick files in the Library here."
                else "It finds this phone by itself on the same Wi-Fi, hotspot or USB link. No address to type.",
                12, Muted, FontWeight.Medium
            )
            Spacer(Modifier.height(8.dp))
            T("This phone is at " + ip.first, 11, Muted, FontWeight.Medium)
        } else {
            T("Waiting for the network...", 16, weight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            T(
                when (Hub.eff) {
                    0 -> "Connect to a Wi-Fi or turn on your phone hotspot."
                    1 -> "Starting the hotspot. This can take a few seconds."
                    else -> "Plug the cable into the PC and turn on USB tethering."
                },
                12, Muted, FontWeight.Medium
            )
        }
    }
}

// ───────────────────────── TIPS ─────────────────────────

@Composable
fun TipsPage(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        SubHeader("Tips", onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            RCard(Modifier.fillMaxWidth()) {
                T("Mobile data", 13, Muted)
                Spacer(Modifier.height(4.dp))
                T("Transfers never use your bundle. Switch mobile data off while sharing so the PC cannot use it either.", 12, TextC, FontWeight.Medium)
            }
            RCard(Modifier.fillMaxWidth()) {
                T("Speed", 13, Muted)
                Spacer(Modifier.height(4.dp))
                T("Best: the PC and phone on the same router Wi-Fi. Next best: your phone hotspot set to 5 GHz. A USB cable is the steadiest. WaveLink sends several files, and big files in pieces, at the same time.", 12, TextC, FontWeight.Medium)
            }
            RCard(Modifier.fillMaxWidth()) {
                T("Sharing lights", 13, Muted)
                Spacer(Modifier.height(4.dp))
                T("On the stage at the top, blue packets ride the upper wave to the PC while it downloads from the phone. Green packets ride the lower wave to the phone while the PC sends files. Both can run at once. The devices flash when a file is done.", 12, TextC, FontWeight.Medium)
            }
            RCard(Modifier.fillMaxWidth()) {
                T("Pairing", 13, Muted)
                Spacer(Modifier.height(4.dp))
                T("The first time, the PC asks and you tap Allow here. After that it connects by itself. Android picks the hotspot name and password when WaveLink has to make a hotspot.", 12, TextC, FontWeight.Medium)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

// ───────────────────────── CONNECTION MODE ─────────────────────────

@Composable
fun ModePage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        SubHeader("Connection mode", onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (Hub.running) T("Stop sharing on the home screen to change this.", 12, Orange, FontWeight.Medium)

            ModeCard(
                3, "Smart", "Default. Uses the Wi-Fi you are on, or makes a hotspot if there is none.",
                listOf(
                    "1. Open WaveLink on the phone and WaveLink PC on the computer.",
                    "2. If both are on the same Wi-Fi or hotspot, they find each other.",
                    "3. If the phone has no network, it makes a hotspot. Join it on the PC once.",
                    "4. The first time, tap Allow on the phone."
                ),
                null
            ) { }

            ModeCard(
                1, "Auto hotspot", "Always makes a temporary hotspot for you.",
                listOf(
                    "1. Switch Location on (Android needs it for this).",
                    "2. Tap the big button and allow the permission.",
                    "3. Join the Wi-Fi shown on screen. Android picks the name and password, the app cannot choose them.",
                    "4. Turn off any normal hotspot first."
                ),
                null
            ) { }

            ModeCard(
                0, "My hotspot", "Uses your own hotspot or router Wi-Fi.",
                listOf(
                    "1. Turn on your phone hotspot. Swipe down and hold Mobile Hotspot.",
                    "2. Set an easy password such as 12345678 under Configure.",
                    "3. Set the band to 5 GHz for speed.",
                    "4. Join that Wi-Fi on the PC, come back and tap the big button."
                ),
                "Open hotspot settings"
            ) { openTethering(ctx) }

            ModeCard(
                2, "USB cable", "Wired and steady. No Wi-Fi needed.",
                listOf(
                    "1. Plug the phone into the PC with a cable.",
                    "2. Turn on USB tethering in the phone's hotspot settings.",
                    "3. Come back and tap the big button. The address appears by itself."
                ),
                "Open tethering settings"
            ) { openTethering(ctx) }

            RCard(Modifier.fillMaxWidth()) {
                T("Always", 13, Muted)
                Spacer(Modifier.height(4.dp))
                T("Switch mobile data off while sharing. Transfers never use data, but the PC could.", 12, TextC, FontWeight.Medium)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun ModeCard(
    id: Int, title: String, sub: String, steps: List<String>, action: String?, onAction: () -> Unit
) {
    val ctx = LocalContext.current
    val sel = Hub.mode == id
    RCard(
        Modifier.fillMaxWidth(), bg = if (sel) Color(0x333F6FB5) else Color.Transparent,
        onClick = { if (!Hub.running) Hub.setMode(ctx, id) }
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                T(title, 17, weight = FontWeight.Bold)
                T(sub, 12, Muted, FontWeight.Medium)
            }
            if (sel) T("Selected", 12, Acc)
        }
        if (sel) {
            Spacer(Modifier.height(10.dp))
            steps.forEach {
                T(it, 12, TextC, FontWeight.Medium)
                Spacer(Modifier.height(4.dp))
            }
            if (action != null) {
                Spacer(Modifier.height(8.dp))
                Pill(action, false) { onAction() }
            }
        }
    }
}

// ───────────────────────── RECEIVED ─────────────────────────

@Composable
fun ReceivedPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val f = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        SubHeader("Received from PC", onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            RCard(Modifier.fillMaxWidth()) {
                if (Hub.received.isEmpty()) T("Nothing yet. Files you send from the PC page appear here.", 13, Muted, FontWeight.Medium)
                for (g in Hub.received.toList()) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            T(g.name, 13)
                            T(fmtSize(g.size) + "  " + f.format(Date(g.time)), 11, Muted, FontWeight.Medium)
                        }
                        if (g.uri != null) {
                            T("Open", 13, Acc, modifier = Modifier.clickable {
                                try {
                                    val type = ctx.contentResolver.getType(g.uri) ?: "*/*"
                                    ctx.startActivity(
                                        Intent(Intent.ACTION_VIEW).setDataAndType(g.uri, type)
                                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                                    )
                                } catch (e: Exception) {
                                }
                            }.padding(8.dp))
                        }
                    }
                }
            }
            RCard(Modifier.fillMaxWidth()) {
                T("Saved in Downloads/WaveLink on this phone.", 12, Muted, FontWeight.Medium)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}
