package com.breadwinner.wavelink

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

// Water: pale sea-glass paper, ink outlines, aqua water.
val Bg = Color(0xFFDDEBF1)
val BgBot = Color(0xFFF2F9FC)
val Paper = Color(0xFFF2F9FC)
val CardC = Color(0xFFFFFFFF)
val Ink = Color(0xFF10344E)
val TextC = Ink
val Mute = Color(0xFF6B8798)
val Muted = Mute
val Mist = Color(0xFFDCEAF0)
val Aqua = Color(0xFF27B4D8)
val AquaD = Color(0xFF1B8DB0)
val Deep = Color(0xFF2F6FB8)
val Acc = AquaD
val Track = Mist
val Orange = Color(0xFFD9503F)
val Coral = Color(0xFFEF6B5B)
val Amber = Color(0xFFF2A93B)
val OnAcc = Ink
val Sand = AquaD
val Teal = Color(0xFF2E9C8A)
val Hair = Color(0x3310344E)
val Shine = Color(0xFFFFFFFF)

enum class Pg { Home, Transfers, More, Mode, Share, Received, Tips, Phone }

@Composable
fun T(
    text: String, size: Int = 13, color: Color = TextC,
    weight: FontWeight = FontWeight.SemiBold, modifier: Modifier = Modifier, maxLines: Int = Int.MAX_VALUE
) {
    Text(
        text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier,
        maxLines = maxLines, overflow = TextOverflow.Ellipsis
    )
}

/** The page behind everything: a pale water-blue wash that gets lighter toward the bottom. */
fun Modifier.sky(): Modifier = this.background(Brush.verticalGradient(listOf(Bg, Paper)))

/** A white card with a thin ink-blue line. */
@Composable
fun RCard(modifier: Modifier = Modifier, bg: Color = Color.Transparent, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    var m = modifier.clip(shape).background(CardC).background(bg).border(1.5.dp, Color(0x2210344E), shape)
    if (onClick != null) m = m.clickable { onClick() }
    Column(m.padding(16.dp)) { content() }
}

@Composable
fun Pill(text: String, filled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    val m = if (filled) {
        Modifier.clip(shape).background(Aqua).border(2.dp, Ink, shape)
    } else {
        Modifier.clip(shape).background(Color.White).border(1.5.dp, Color(0x4410344E), shape)
    }
    Box(
        Modifier.then(m).clickable { onClick() }.padding(horizontal = 18.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) { T(text, 13, Ink, FontWeight.Bold) }
}

@Composable
fun Qr(text: String, dp: Dp) {
    val m = remember(text) {
        try {
            QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, mapOf(EncodeHintType.MARGIN to 1))
        } catch (e: Exception) {
            null
        }
    }
    Canvas(Modifier.size(dp).clip(RoundedCornerShape(6.dp)).background(Color.White)) {
        if (m != null) {
            val cell = this.size.width / m.width
            for (y in 0 until m.height) {
                for (x in 0 until m.width) {
                    if (m.get(x, y)) drawRect(Color.Black, Offset(x * cell, y * cell), Size(cell + 0.6f, cell + 0.6f))
                }
            }
        }
    }
}

private fun wifiEsc(s: String): String =
    s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace(":", "\\:").replace("\"", "\\\"")

fun openTethering(c: Context) {
    val tries = listOf(
        Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"),
        Intent(Settings.ACTION_WIRELESS_SETTINGS)
    )
    for (i in tries) {
        try {
            c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            return
        } catch (e: Exception) {
        }
    }
}

// ───────────────────────── ROOT ─────────────────────────

@Composable
fun WaveLinkApp() {
    var pg by remember { mutableStateOf(Pg.Home) }
    var prev by remember { mutableStateOf(Pg.Home) }
    fun nav(t: Pg) {
        prev = pg
        pg = t
    }

    BackHandler(pg != Pg.Home) {
        pg = when (pg) {
            Pg.Share -> prev
            Pg.Mode, Pg.Received, Pg.Tips, Pg.Phone -> Pg.More
            else -> Pg.Home
        }
    }

    // one overall picture of everything moving, refreshed about twice a second
    LaunchedEffect(Unit) {
        while (true) {
            Flow.tick()
            delay(400)
        }
    }

    val req = Hub.pairReq
    if (req != null) {
        AlertDialog(
            onDismissRequest = { Hub.pairAnswer = 2 },
            title = { Text(req.name + " wants to connect") },
            text = { Text("Allow this PC to send files to your phone and fetch the files you share. Only say yes if it is your own PC.") },
            confirmButton = { TextButton(onClick = { Hub.pairAnswer = 1 }) { Text("Allow") } },
            dismissButton = { TextButton(onClick = { Hub.pairAnswer = 2 }) { Text("Not now") } }
        )
    }

    val tabs = pg == Pg.Home || pg == Pg.Transfers || pg == Pg.More
    Column(Modifier.fillMaxSize().sky()) {
        Box(Modifier.weight(1f).fillMaxWidth().consumeWindowInsets(if (tabs) WindowInsets.navigationBars else WindowInsets(0))) {
            when (pg) {
                Pg.Home -> HomePage { nav(it) }
                Pg.Transfers -> TransfersPage()
                Pg.More -> MorePage { nav(it) }
                Pg.Mode -> ModePage { pg = Pg.More }
                Pg.Share -> LibraryPage { pg = prev }
                Pg.Received -> ReceivedPage { pg = Pg.More }
                Pg.Tips -> TipsPage { pg = Pg.More }
                Pg.Phone -> PhonePage({ pg = Pg.More }, { nav(Pg.Share) })
            }
        }
        if (tabs) NavBar(pg) { pg = it }
    }
}

/** Small line pictures for the tabs and the More list. */
@Composable
fun Glyph(kind: Int, color: Color, size: Dp = 24.dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val sw = 2.2.dp.toPx()
        val st = Stroke(sw, cap = StrokeCap.Round)
        when (kind) {
            0 -> { // home: a drop of water
                val p = Path()
                p.moveTo(w * 0.5f, w * 0.08f)
                p.cubicTo(w * 0.9f, w * 0.5f, w * 0.85f, w * 0.92f, w * 0.5f, w * 0.92f)
                p.cubicTo(w * 0.15f, w * 0.92f, w * 0.1f, w * 0.5f, w * 0.5f, w * 0.08f)
                drawPath(p, color, style = st)
            }
            1 -> { // transfers: two arrows
                drawLine(color, Offset(w * 0.3f, w * 0.15f), Offset(w * 0.3f, w * 0.85f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.12f, w * 0.33f), Offset(w * 0.3f, w * 0.13f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.48f, w * 0.33f), Offset(w * 0.3f, w * 0.13f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.7f, w * 0.15f), Offset(w * 0.7f, w * 0.85f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.52f, w * 0.67f), Offset(w * 0.7f, w * 0.87f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.88f, w * 0.67f), Offset(w * 0.7f, w * 0.87f), sw, StrokeCap.Round)
            }
            2 -> { // more: three dots
                for (k in 0..2) drawCircle(color, 2.4.dp.toPx(), Offset(w * (0.2f + 0.3f * k), w * 0.5f))
            }
            3 -> { // connection: signal bars
                for (k in 0..3) {
                    val x = w * (0.16f + 0.22f * k)
                    drawLine(color, Offset(x, w * 0.88f), Offset(x, w * (0.7f - 0.17f * k)), sw * 1.2f, StrokeCap.Round)
                }
            }
            4 -> { // phone to phone: two phones
                drawRoundRect(color, Offset(w * 0.1f, w * 0.18f), Size(w * 0.34f, w * 0.64f), CornerRadius(4.dp.toPx()), style = st)
                drawRoundRect(color, Offset(w * 0.56f, w * 0.18f), Size(w * 0.34f, w * 0.64f), CornerRadius(4.dp.toPx()), style = st)
            }
            5 -> { // library: a tray with an arrow up
                drawLine(color, Offset(w * 0.5f, w * 0.7f), Offset(w * 0.5f, w * 0.14f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.3f, w * 0.34f), Offset(w * 0.5f, w * 0.14f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.7f, w * 0.34f), Offset(w * 0.5f, w * 0.14f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.14f, w * 0.88f), Offset(w * 0.86f, w * 0.88f), sw, StrokeCap.Round)
            }
            6 -> { // received: a tray with an arrow down
                drawLine(color, Offset(w * 0.5f, w * 0.12f), Offset(w * 0.5f, w * 0.68f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.3f, w * 0.48f), Offset(w * 0.5f, w * 0.68f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.7f, w * 0.48f), Offset(w * 0.5f, w * 0.68f), sw, StrokeCap.Round)
                drawLine(color, Offset(w * 0.14f, w * 0.88f), Offset(w * 0.86f, w * 0.88f), sw, StrokeCap.Round)
            }
            7 -> { // qr: three corner squares
                drawRoundRect(color, Offset(w * 0.1f, w * 0.1f), Size(w * 0.3f, w * 0.3f), CornerRadius(2.dp.toPx()), style = st)
                drawRoundRect(color, Offset(w * 0.6f, w * 0.1f), Size(w * 0.3f, w * 0.3f), CornerRadius(2.dp.toPx()), style = st)
                drawRoundRect(color, Offset(w * 0.1f, w * 0.6f), Size(w * 0.3f, w * 0.3f), CornerRadius(2.dp.toPx()), style = st)
                drawCircle(color, 2.dp.toPx(), Offset(w * 0.72f, w * 0.72f))
                drawCircle(color, 2.dp.toPx(), Offset(w * 0.88f, w * 0.88f))
            }
            else -> { // tips: a circle with a dot and a stem
                drawCircle(color, w * 0.4f, Offset(w / 2, w / 2), style = st)
                drawCircle(color, 1.8.dp.toPx(), Offset(w / 2, w * 0.32f))
                drawLine(color, Offset(w / 2, w * 0.46f), Offset(w / 2, w * 0.68f), sw, StrokeCap.Round)
            }
        }
    }
}

@Composable
fun NavBar(cur: Pg, go: (Pg) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Color.White).border(1.dp, Color(0x2210344E)).navigationBarsPadding()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        for ((pgx, label, kind) in listOf(Triple(Pg.Home, "Home", 0), Triple(Pg.Transfers, "Transfers", 1), Triple(Pg.More, "More", 2))) {
            val on = cur == pgx
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).clickable { go(pgx) }.padding(vertical = 6.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier.clip(RoundedCornerShape(12.dp)).background(if (on) Color(0x3327B4D8) else Color.Transparent)
                        .padding(horizontal = 16.dp, vertical = 3.dp)
                ) { Glyph(kind, if (on) Ink else Mute) }
                T(label, 11, if (on) Ink else Mute, if (on) FontWeight.Bold else FontWeight.Medium)
            }
        }
    }
}

@Composable
fun SubHeader(title: String, onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(44.dp).clip(CircleShape).background(Color.White).border(1.5.dp, Color(0x3310344E), CircleShape).clickable { onBack() },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size(22.dp)) {
                val w = 2.5.dp.toPx()
                drawLine(Ink, Offset(size.width * 0.62f, size.height * 0.2f), Offset(size.width * 0.32f, size.height * 0.5f), w, StrokeCap.Round)
                drawLine(Ink, Offset(size.width * 0.32f, size.height * 0.5f), Offset(size.width * 0.62f, size.height * 0.8f), w, StrokeCap.Round)
            }
        }
        Spacer(Modifier.width(12.dp))
        T(title, 22, weight = FontWeight.ExtraBold)
    }
}

// ───────────────────────── HOME ─────────────────────────

@Composable
fun HomePage(go: (Pg) -> Unit) {
    val ctx = LocalContext.current
    var ip by remember { mutableStateOf<Pair<String, String>?>(null) }

    LaunchedEffect(Hub.running, Hub.eff) {
        while (Hub.running) {
            ip = withContext(Dispatchers.Default) { findIp(Hub.eff) }
            Hub.recount()
            delay(2000)
        }
        ip = null
    }

    val linked = Hub.running && Hub.devices > 0
    // a splash when sharing starts and when the PC links
    var kick by remember { mutableStateOf(0) }
    LaunchedEffect(Hub.running) { if (Hub.running) kick += 1 }
    LaunchedEffect(linked) { if (linked) kick += 1 }

    val doStart: () -> Unit = {
        ContextCompat.startForegroundService(
            ctx, Intent(ctx, ShareService::class.java).putExtra("mode", Hub.mode)
        )
    }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { doStart() }
    val toggle: () -> Unit = {
        if (Hub.running) {
            ctx.stopService(Intent(ctx, ShareService::class.java))
        } else {
            val need = ArrayList<String>()
            val mayHotspot = Hub.mode == 1 || Hub.mode == 3
            if (Build.VERSION.SDK_INT >= 33) {
                need.add(Manifest.permission.POST_NOTIFICATIONS)
                if (mayHotspot) need.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            } else if (mayHotspot) {
                need.add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
            val missing = need.filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isEmpty()) doStart() else perms.launch(missing.toTypedArray())
        }
    }

    // open the app, and it starts looking for your PC by itself (once per launch)
    LaunchedEffect(Unit) {
        if (!Hub.autoTried && !Hub.running) {
            Hub.autoTried = true
            toggle()
        }
    }

    // connect to the PC by QR: scan the code on the PC screen, nothing to type
    var scanning by remember { mutableStateOf(false) }
    var held by remember { mutableStateOf("") }
    val joinNow: (String) -> Unit = { raw ->
        if (!Hub.running) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, ShareService::class.java).putExtra("mode", 0))
        }
        P2p.scope.launch {
            delay(700)
            joinPc(ctx.applicationContext, raw)
        }
    }
    val permJoin = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { joinNow(held) }
    val onScanned: (String) -> Unit = { raw ->
        scanning = false
        held = raw
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            need.add(Manifest.permission.POST_NOTIFICATIONS)
            need.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        } else {
            need.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        val missing = need.filter { ContextCompat.checkSelfPermission(ctx, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) joinNow(raw) else permJoin.launch(missing.toTypedArray())
    }
    if (scanning) ScanDialog(onResult = onScanned, onClose = { scanning = false })

    val moving = Flow.on && !Flow.finished
    val level = when {
        !Hub.running -> 0.14f
        moving -> 0.3f + 0.65f * Flow.frac
        Flow.finished -> 0.95f
        linked -> 0.62f
        else -> 0.38f
    }
    val title = when {
        !Hub.running -> "Tap to start"
        moving -> (Flow.frac * 100).toInt().toString() + "%"
        Flow.finished -> "All done"
        linked -> "PC linked"
        else -> "Looking for your PC"
    }
    val sub = when {
        !Hub.running -> "WaveLink is off"
        moving -> String.format(Locale.US, "%.1f MB/s", Flow.mbs)
        linked -> "Ready to move files"
        else -> "Same Wi-Fi, hotspot or USB"
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            T("WaveLink", 26, weight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
            Box(
                Modifier.clip(RoundedCornerShape(12.dp)).background(if (linked) Color(0x332E9C8A) else Color(0x1A10344E))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) { T(if (linked) "Linked" else if (Hub.running) "Searching" else "Off", 12, if (linked) Teal else Mute, FontWeight.Bold) }
        }

        Column(
            Modifier.weight(1f).fillMaxWidth().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            WaterOrb(level, title, sub, Flow.burst * 1000 + kick, 220.dp, toggle)

            if (Hub.hotspotMsg.isNotEmpty() && (Hub.eff == 1 || !Hub.running)) {
                T(Hub.hotspotMsg, 13, Orange, modifier = Modifier.padding(horizontal = 8.dp))
            }

            RCard(Modifier.fillMaxWidth()) {
                T("Everything moving", 13, Mute)
                Spacer(Modifier.height(2.dp))
                WaterBar(Flow.frac, Flow.mbs, Flow.eta, Flow.finished, Flow.burst, if (Hub.running) "Ready when you are" else "Start sharing first")
            }

            RCard(Modifier.fillMaxWidth(), onClick = { scanning = true }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Color(0x2227B4D8)),
                        contentAlignment = Alignment.Center
                    ) { Glyph(7, Ink, 26.dp) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        T("Connect by QR", 16, weight = FontWeight.ExtraBold)
                        T(
                            if (PcLink.msg.isNotEmpty()) PcLink.msg
                            else "On the PC tap Connect by QR, then scan its code here. Nothing to type.",
                            12, if (PcLink.joined) Teal else Mute, FontWeight.Medium
                        )
                    }
                }
            }

            RCard(Modifier.fillMaxWidth(), onClick = { go(Pg.Share) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Color(0x2227B4D8)),
                        contentAlignment = Alignment.Center
                    ) { Glyph(5, Ink, 26.dp) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        T("Library", 16, weight = FontWeight.ExtraBold)
                        T(
                            if (Hub.items.isEmpty()) "Choose what to share" else "${Hub.items.size} chosen",
                            12, Mute, FontWeight.Medium
                        )
                    }
                }
            }

            if (Hub.running) AddressCard(ip)
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
fun AddressCard(ip: Pair<String, String>?) {
    RCard(Modifier.fillMaxWidth()) {
        if (Hub.eff == 1) {
            T("Join this Wi-Fi on the PC once", 11, Muted, FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            T("Wi-Fi name", 11, Muted, FontWeight.Medium)
            T(if (Hub.ssid.isNotEmpty()) Hub.ssid else "Starting...", 22, weight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            T("Password", 11, Muted, FontWeight.Medium)
            T(if (Hub.pass.isNotEmpty()) Hub.pass else "...", 22, Acc, FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
        }
        if (ip != null) {
            T(
                if (Hub.devices > 0) "PC linked" else "Open WaveLink PC on your computer",
                18, if (Hub.devices > 0) Teal else TextC, FontWeight.Bold
            )
            Spacer(Modifier.height(4.dp))
            T(
                if (Hub.devices > 0) "It found this phone by itself. Drop files on the PC app, or pick files in the Library here."
                else "It finds this phone by itself on the same Wi-Fi, hotspot or USB link. Or use Connect by QR.",
                12, Muted, FontWeight.Medium
            )
            Spacer(Modifier.height(8.dp))
            T("This phone is at " + ip.first, 11, Muted, FontWeight.Medium)
        } else {
            T("Waiting for the network...", 16, weight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            T(
                when (Hub.eff) {
                    0 -> "Connect to a Wi-Fi or turn on your phone hotspot."
                    1 -> "Starting the hotspot. This can take a few seconds."
                    else -> "Plug the cable into the PC and turn on USB tethering."
                },
                12, Muted, FontWeight.Medium
            )
        }
    }
}

// ───────────────────────── TRANSFERS ─────────────────────────

@Composable
fun TransfersPage() {
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp)) {
            T("Transfers", 26, weight = FontWeight.ExtraBold)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            RCard(Modifier.fillMaxWidth()) {
                WaterBar(Flow.frac, Flow.mbs, Flow.eta, Flow.finished, Flow.burst)
                Spacer(Modifier.height(6.dp))
                if (Flow.on) {
                    T(fmtSize(Flow.doneBytes) + " of " + fmtSize(Flow.totalBytes), 12, Mute, FontWeight.Medium)
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Speed("Phone to PC", Flow.upMbs, Aqua)
                    Speed("PC to phone", Flow.dnMbs, Teal)
                }
            }
            RCard(Modifier.fillMaxWidth()) {
                T("Files", 13, Mute)
                Spacer(Modifier.height(6.dp))
                if (Flow.lines.isEmpty()) {
                    T("Nothing yet. Files you share, and files the PC sends, show up here with one status each.", 13, Mute, FontWeight.Medium)
                }
                for (l in Flow.lines) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        Canvas(Modifier.size(20.dp)) {
                            val w = size.width
                            val c = if (l.up) AquaD else Teal
                            val sw = 2.2.dp.toPx()
                            val dir = if (l.up) -1f else 1f
                            drawLine(c, Offset(w * 0.5f, w * 0.5f - dir * w * 0.36f), Offset(w * 0.5f, w * 0.5f + dir * w * 0.36f), sw, StrokeCap.Round)
                            drawLine(c, Offset(w * 0.3f, w * 0.5f + dir * w * 0.16f), Offset(w * 0.5f, w * 0.5f + dir * w * 0.36f), sw, StrokeCap.Round)
                            drawLine(c, Offset(w * 0.7f, w * 0.5f + dir * w * 0.16f), Offset(w * 0.5f, w * 0.5f + dir * w * 0.36f), sw, StrokeCap.Round)
                        }
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            T(l.name, 13, maxLines = 1)
                            T(fmtSize(l.size), 11, Mute, FontWeight.Medium)
                        }
                        val (txt, col) = when (l.state) {
                            2 -> "Done" to Teal
                            1 -> "Moving" to AquaD
                            else -> "Waiting" to Mute
                        }
                        T(txt, 12, col, FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun Speed(label: String, mbs: Float, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(if (mbs > 0f) color else color.copy(alpha = 0.3f)))
        Spacer(Modifier.width(8.dp))
        Column {
            T(label, 11, Mute, FontWeight.Medium)
            T(if (mbs > 0f) String.format(Locale.US, "%.1f MB/s", mbs) else "idle", 15, if (mbs > 0f) color else Mute, FontWeight.Bold)
        }
    }
}

// ───────────────────────── MORE ─────────────────────────

@Composable
fun MorePage(go: (Pg) -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp)) {
            T("More", 26, weight = FontWeight.ExtraBold)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Shelf2("Connect") {
                MoreRow(3, "Connection mode", "Smart, hotspot, USB", false) { go(Pg.Mode) }
                MoreRow(4, "Phone to phone", "Send straight to another phone", true) { go(Pg.Phone) }
            }
            Shelf2("Files") {
                MoreRow(5, "Library", "Choose what to share", false) { go(Pg.Share) }
                MoreRow(6, "Received from PC", "Saved in Downloads/WaveLink", true) { go(Pg.Received) }
            }
            Shelf2("Help") {
                MoreRow(8, "Tips", "Speed, pairing, mobile data", true) { go(Pg.Tips) }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun Shelf2(title: String, content: @Composable () -> Unit) {
    Column {
        T(title.uppercase(Locale.US), 11, Mute, FontWeight.Bold, Modifier.padding(start = 6.dp, bottom = 6.dp))
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Color.White)
                .border(1.5.dp, Color(0x2210344E), RoundedCornerShape(20.dp))
        ) { content() }
    }
}

@Composable
private fun MoreRow(kind: Int, title: String, sub: String, last: Boolean, onClick: () -> Unit) {
    Column {
        Row(
            Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(38.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x2227B4D8)),
                contentAlignment = Alignment.Center
            ) { Glyph(kind, Ink, 22.dp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                T(title, 15, weight = FontWeight.Bold)
                T(sub, 12, Mute, FontWeight.Medium)
            }
        }
        if (!last) Box(Modifier.fillMaxWidth().padding(start = 64.dp).height(1.dp).background(Mist))
    }
}

// ───────────────────────── TIPS ─────────────────────────

@Composable
fun TipsPage(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        SubHeader("Tips", onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            RCard(Modifier.fillMaxWidth()) {
                T("Mobile data", 13, Muted)
                Spacer(Modifier.height(4.dp))
                T("Transfers never use your bundle. Switch mobile data off while sharing so the PC cannot use it either.", 12, TextC, FontWeight.Medium)
            }
            RCard(Modifier.fillMaxWidth()) {
                T("Speed", 13, Muted)
                Spacer(Modifier.height(4.dp))
                T("Best: the PC and phone on the same router Wi-Fi. Next best: your phone hotspot set to 5 GHz. A USB cable is the steadiest. WaveLink sends several files, and big files in pieces, at the same time.", 12, TextC, FontWeight.Medium)
            }
            RCard(Modifier.fillMaxWidth()) {
                T("The water", 13, Muted)
                Spacer(Modifier.height(4.dp))
                T("The big circle fills as your PC links and as files move. One bar shows everything at once, both directions, with the speed and the time left. The Transfers tab lists each file as Waiting, Moving or Done. It splashes when a batch is finished.", 12, TextC, FontWeight.Medium)
            }
            RCard(Modifier.fillMaxWidth()) {
                T("Pairing", 13, Muted)
                Spacer(Modifier.height(4.dp))
                T("The first time, the PC asks and you tap Allow here. After that it connects by itself. Android picks the hotspot name and password when WaveLink has to make a hotspot.", 12, TextC, FontWeight.Medium)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

// ───────────────────────── CONNECTION MODE ─────────────────────────

@Composable
fun ModePage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        SubHeader("Connection mode", onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (Hub.running) T("Stop sharing on the home screen to change this.", 12, Orange, FontWeight.Medium)

            ModeCard(
                3, "Smart", "Default. Uses the Wi-Fi you are on, or makes a hotspot if there is none.",
                listOf(
                    "1. Open WaveLink on the phone and WaveLink PC on the computer.",
                    "2. If both are on the same Wi-Fi or hotspot, they find each other.",
                    "3. Or tap Connect by QR on the PC and scan its code with this phone.",
                    "4. The first time, tap Allow on the phone."
                ),
                null
            ) { }

            ModeCard(
                1, "Auto hotspot", "Always makes a temporary hotspot for you.",
                listOf(
                    "1. Switch Location on (Android needs it for this).",
                    "2. Tap the big button and allow the permission.",
                    "3. Join the Wi-Fi shown on screen. Android picks the name and password, the app cannot choose them.",
                    "4. Turn off any normal hotspot first."
                ),
                null
            ) { }

            ModeCard(
                0, "My hotspot", "Uses your own hotspot or router Wi-Fi.",
                listOf(
                    "1. Turn on your phone hotspot. Swipe down and hold Mobile Hotspot.",
                    "2. Set an easy password such as 12345678 under Configure.",
                    "3. Set the band to 5 GHz for speed.",
                    "4. Join that Wi-Fi on the PC, come back and tap the big button."
                ),
                "Open hotspot settings"
            ) { openTethering(ctx) }

            ModeCard(
                2, "USB cable", "Wired and steady. No Wi-Fi needed.",
                listOf(
                    "1. Plug the phone into the PC with a cable.",
                    "2. Turn on USB tethering in the phone's hotspot settings.",
                    "3. Come back and tap the big button. The address appears by itself."
                ),
                "Open tethering settings"
            ) { openTethering(ctx) }

            RCard(Modifier.fillMaxWidth()) {
                T("Always", 13, Muted)
                Spacer(Modifier.height(4.dp))
                T("Switch mobile data off while sharing. Transfers never use data, but the PC could.", 12, TextC, FontWeight.Medium)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun ModeCard(
    id: Int, title: String, sub: String, steps: List<String>, action: String?, onAction: () -> Unit
) {
    val ctx = LocalContext.current
    val sel = Hub.mode == id
    RCard(
        Modifier.fillMaxWidth(), bg = if (sel) Color(0x333F6FB5) else Color.Transparent,
        onClick = { if (!Hub.running) Hub.setMode(ctx, id) }
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                T(title, 17, weight = FontWeight.Bold)
                T(sub, 12, Muted, FontWeight.Medium)
            }
            if (sel) T("Selected", 12, Acc)
        }
        if (sel) {
            Spacer(Modifier.height(10.dp))
            steps.forEach {
                T(it, 12, TextC, FontWeight.Medium)
                Spacer(Modifier.height(4.dp))
            }
            if (action != null) {
                Spacer(Modifier.height(8.dp))
                Pill(action, false) { onAction() }
            }
        }
    }
}

// ───────────────────────── RECEIVED ─────────────────────────

@Composable
fun ReceivedPage(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val f = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        SubHeader("Received from PC", onBack)
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            RCard(Modifier.fillMaxWidth()) {
                if (Hub.received.isEmpty()) T("Nothing yet. Files you send from the PC page appear here.", 13, Muted, FontWeight.Medium)
                for (g in Hub.received.toList()) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            T(g.name, 13)
                            T(fmtSize(g.size) + "  " + f.format(Date(g.time)), 11, Muted, FontWeight.Medium)
                        }
                        if (g.uri != null) {
                            T("Open", 13, Acc, modifier = Modifier.clickable {
                                try {
                                    val type = ctx.contentResolver.getType(g.uri) ?: "*/*"
                                    ctx.startActivity(
                                        Intent(Intent.ACTION_VIEW).setDataAndType(g.uri, type)
                                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                                    )
                                } catch (e: Exception) {
                                }
                            }.padding(8.dp))
                        }
                    }
                }
            }
            RCard(Modifier.fillMaxWidth()) {
                T("Saved in Downloads/WaveLink on this phone.", 12, Muted, FontWeight.Medium)
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}
